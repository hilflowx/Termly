# Termly — Android Native

Termly adalah aplikasi akademik offline-first untuk jadwal kuliah, deadline, dan pelacakan IPS/IPK. Implementasi menggunakan Kotlin, Jetpack Compose Material 3, Navigation Compose, Room, DataStore Preferences, Glance, AlarmManager, ML Kit OCR, PdfRenderer/PDFBox, MVVM, dan unit test untuk perhitungan IPK/IPS.

## Menjalankan

1. Buka folder `Termly` melalui Android Studio versi terbaru.
2. Pastikan JDK 17 dan Android SDK Platform 36 terpasang.
3. Sinkronkan Gradle, lalu jalankan konfigurasi `app` ke emulator/perangkat Android API 26 atau lebih baru.
4. Jika Android Studio meminta pembaruan plugin atau dependency, tinjau versi yang kompatibel sebelum menerima pembaruan otomatis.
5. Jika sinkronisasi mengeluhkan `gradle-wrapper.jar` yang tidak tersedia, jalankan `gradle wrapper --gradle-version 8.13` dari terminal yang memiliki Gradle 8.13 terpasang, lalu sinkronkan ulang. Skrip `gradlew` di paket ini juga dapat memakai instalasi Gradle yang tersedia di `PATH`.

## Struktur

- `data/local`: entitas Room, DAO, dan database lokal.
- `data/preferences`: profil dan pengaturan via DataStore.
- `data/repository`: akses data.
- `domain`: kalkulasi IPS/IPK dan penggabungan jadwal rutin/pengecualian.
- `ui/navigation`: navigasi utama dan speed dial.
- `ui/screens`: Beranda, Jadwal, Tugas, Nilai, Profil, Pengaturan, Mata Kuliah, serta cadangan.
- `ui/importing`: pemrosesan PDF/OCR dan layar pratinjau-edit-simpan.
- `util`: pengingat deadline melalui AlarmManager dan notifikasi.
- `widget`: widget layar utama Glance responsif.
- `app/src/test`: unit test fungsi kalkulasi IPS/IPK.

## Catatan implementasi

- Simulasi IPK menambahkan perkiraan nilai dan SKS ke perhitungan tanpa mengubah data asli. Alarm deadline dijadwalkan ulang setelah perangkat reboot. Widget menggunakan penggabungan jadwal rutin dan pengecualian per tanggal.

- Semua data akademik utama berada di Room, sedangkan profil/pengaturan berada di DataStore.
- Target SDK diatur ke API 36, sesuai persyaratan Google Play yang berlaku sejak 31 Agustus 2026 untuk aplikasi baru dan pembaruan.
- PDF berbasis teks diekstrak menggunakan PDFBox Android. Foto atau PDF hasil scan diproses melalui ML Kit di perangkat. Parser bersifat heuristik dan pratinjau bisa diedit karena format KRS/KHS berbeda antar kampus.
- Android dapat membatasi alarm presisi; aplikasi memakai alarm presisi jika izin tersedia dan fallback yang diizinkan sistem bila tidak. Izin notifikasi diminta saat aplikasi pertama kali dibuka pada Android 13+.
- Cadangan JSON mencakup data akademik dan profil/pengaturan. Pemulihan memvalidasi versi format, memasukkan data secara transaksional, dan menghindari duplikasi entitas yang cocok. Impor data dari cadangan bersifat penggabungan, bukan penghapusan seluruh data lama.
- Proyek disusun pada level sumber. Proses Gradle build belum dapat dijalankan di lingkungan pembuatan karena Android SDK/Gradle tidak tersedia di container ini; karena itu, build dan eksekusi belum bisa saya klaim berhasil. Pastikan sinkronisasi dan unit test dijalankan di Android Studio pada toolchain lokal.
