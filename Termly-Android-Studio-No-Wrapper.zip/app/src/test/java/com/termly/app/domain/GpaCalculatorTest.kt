package com.termly.app.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class GpaCalculatorTest {
    private val scale = GradeScale(mapOf("A" to 4.0, "B" to 3.0, "C" to 2.0, "D" to 1.0, "E" to 0.0))

    @Test fun ipsIsWeightedByCredits() {
        val result = GpaCalculator.ips(listOf(GradeRecord(1, 1, "A", 3), GradeRecord(2, 1, "B", 2)), scale)
        assertEquals(3.6, result!!, 0.0001)
    }

    @Test fun ipkHighestUsesHighestAttemptPerCourse() {
        val result = GpaCalculator.ipk(listOf(GradeRecord(1, 1, "C", 3), GradeRecord(1, 2, "A", 3), GradeRecord(2, 2, "B", 2)), scale, RepeatedGradeRule.HIGHEST)
        assertEquals(3.6, result!!, 0.0001)
    }

    @Test fun ipkLatestUsesMostRecentSemesterAttempt() {
        val result = GpaCalculator.ipk(listOf(GradeRecord(1, 1, "A", 3), GradeRecord(1, 2, "C", 3), GradeRecord(2, 2, "B", 3)), scale, RepeatedGradeRule.LATEST)
        assertEquals(2.5, result!!, 0.0001)
    }

    @Test fun averageIsNullWhenThereAreNoValidCredits() {
        assertNull(GpaCalculator.ips(emptyList(), scale))
    }
}
