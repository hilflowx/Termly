package com.termly.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightScheme = lightColorScheme(
    primary = Teal, onPrimary = Color.White, secondary = Amber, onSecondary = Color(0xFF302000),
    background = BackgroundLight, onBackground = TextDark, surface = SurfaceLight, onSurface = TextDark,
    surfaceVariant = Color(0xFFE7EFEE), onSurfaceVariant = Color(0xFF405452), error = Danger
)
private val DarkScheme = darkColorScheme(
    primary = Color(0xFF5EEAD4), onPrimary = Color(0xFF003731), secondary = Color(0xFFFBBF24),
    background = BackgroundDark, onBackground = Color(0xFFE5EEF0), surface = SurfaceDark,
    onSurface = Color(0xFFE5EEF0), surfaceVariant = Color(0xFF30434A), onSurfaceVariant = Color(0xFFC4D3D8)
)

@Composable
fun TermlyTheme(themeMode: String, dynamicColor: Boolean, content: @Composable () -> Unit) {
    val systemDark = isSystemInDarkTheme()
    val dark = when (themeMode) { "light" -> false; "dark" -> true; else -> systemDark }
    val context = LocalContext.current
    val colors = if (dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) androidx.compose.material3.dynamicDarkColorScheme(context) else androidx.compose.material3.dynamicLightColorScheme(context)
    } else if (dark) DarkScheme else LightScheme
    MaterialTheme(colorScheme = colors, typography = androidx.compose.material3.Typography(), content = content)
}
