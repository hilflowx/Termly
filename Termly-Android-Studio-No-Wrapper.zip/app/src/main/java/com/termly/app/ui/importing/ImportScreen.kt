package com.termly.app.ui.importing

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.FileOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.termly.app.ui.TermlyViewModel
import com.termly.app.ui.components.TermlyCard
import kotlinx.coroutines.launch

@Composable
fun ImportScreen(kind: String, viewModel: TermlyViewModel, onBack: () -> Unit, onSwitchKind: (String) -> Unit, onSaved: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var rows by remember(kind) { mutableStateOf<List<ImportPreviewRow>>(emptyList()) }
    var source by remember(kind) { mutableStateOf("") }
    var rawText by remember(kind) { mutableStateOf("") }
    var semester by remember(kind) { mutableStateOf("Semester 1") }
    var loading by remember(kind) { mutableStateOf(false) }
    var error by remember(kind) { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            loading = true; error = ""
            runCatching { DocumentImportParser(context).parse(uri, kind) }
                .onSuccess { result -> rows = result.rows; rawText = result.rawText; source = result.sourceLabel; if (rows.isEmpty()) error = "Teks terdeteksi, tetapi baris belum dikenali. Kamu bisa mencoba foto/PDF yang lebih jelas." }
                .onFailure { error = "File tidak bisa dibaca. Coba file PDF atau gambar lain. (${it.message.orEmpty()})" }
            loading = false
        }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp).imePadding()) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Kembali") }
            Column(Modifier.weight(1f)) {
                Text(if (kind == "khs") "Impor KHS" else "Impor KRS", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Baca file, periksa hasil, lalu simpan", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = { onSwitchKind(if (kind == "khs") "krs" else "khs") }) { Text(if (kind == "khs") "Pilih KRS" else "Pilih KHS", maxLines = 1) }
        }
        if (kind == "khs") OutlinedTextField(semester, { semester = it }, label = { Text("Semester untuk nilai ini") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))
        Button(onClick = { picker.launch(arrayOf("application/pdf", "image/*")) }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp), enabled = !loading) {
            Icon(Icons.Outlined.FileOpen, contentDescription = null); Spacer(Modifier.width(8.dp)); Text(if (loading) "Membaca file…" else "Pilih PDF atau foto")
        }
        if (source.isNotBlank()) Text("Sumber: $source · ${rows.size} baris terdeteksi", modifier = Modifier.padding(top = 8.dp), style = MaterialTheme.typography.bodySmall)
        if (error.isNotBlank()) Text(error, modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        if (rows.isEmpty() && !loading) {
            Spacer(Modifier.height(12.dp))
            TermlyCard {
                Text("Sebelum menyimpan", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text("PDF berbasis teks dibaca langsung. Foto dan PDF hasil scan diproses dengan OCR di perangkat. Hasil pembacaan bisa kurang akurat, jadi periksa daftar pratinjau terlebih dahulu.", style = MaterialTheme.typography.bodyMedium)
            }
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 12.dp, bottom = 100.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            itemsIndexed(rows, key = { index, _ -> "preview-row-$index" }) { index, row ->
                var name by remember(row.name) { mutableStateOf(row.name) }
                var sks by remember(row.sks) { mutableStateOf(row.sks.toString()) }
                var grade by remember(row.grade) { mutableStateOf(row.grade) }
                var day by remember(row.day) { mutableStateOf(row.day.toString()) }
                var start by remember(row.start) { mutableStateOf(row.start) }
                var end by remember(row.end) { mutableStateOf(row.end) }
                var room by remember(row.room) { mutableStateOf(row.room) }
                TermlyCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Data ${index + 1}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        if (row.confidence < 0.7f) Surface(color = Color(0xFFFFF0BC), contentColor = Color(0xFF7A4B00), shape = RoundedCornerShape(50)) { Text("Perlu dicek", modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp), style = MaterialTheme.typography.labelSmall) }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(name, { name = it; rows = rows.toMutableList().also { list -> list[index] = list[index].copy(name = it) } }, label = { Text("Mata kuliah") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(sks, { value -> sks = value; val v = value.toIntOrNull(); if (v != null) rows = rows.toMutableList().also { list -> list[index] = list[index].copy(sks = v.coerceIn(1, 6)) } }, label = { Text("SKS") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                        if (kind == "khs") OutlinedTextField(grade, { grade = it.uppercase(); rows = rows.toMutableList().also { list -> list[index] = list[index].copy(grade = it.uppercase()) } }, label = { Text("Nilai") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    if (kind == "krs") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(day, { value -> day = value; rows = rows.toMutableList().also { list -> list[index] = list[index].copy(day = value.toIntOrNull() ?: 0) } }, label = { Text("Hari 1–7") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                            OutlinedTextField(start, { value -> start = value; rows = rows.toMutableList().also { list -> list[index] = list[index].copy(start = value) } }, label = { Text("Mulai") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(end, { value -> end = value; rows = rows.toMutableList().also { list -> list[index] = list[index].copy(end = value) } }, label = { Text("Selesai") }, modifier = Modifier.weight(1f), singleLine = true)
                        }
                        OutlinedTextField(room, { value -> room = value; rows = rows.toMutableList().also { list -> list[index] = list[index].copy(room = value) } }, label = { Text("Ruang (opsional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    }
                    TextButton(onClick = { rows = rows.toMutableList().also { it.removeAt(index) } }) { Text("Hapus baris") }
                }
            }
            if (rows.isNotEmpty()) item {
                Button(onClick = { scope.launch { viewModel.importRows(rows, kind, semester); onSaved() } }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp), enabled = !loading) { Text("Simpan ${rows.size} data") }
            }
            if (rawText.isNotBlank() && rows.isEmpty()) item { Text("Teks mentah ditemukan, tapi formatnya belum cocok. Coba edit foto atau file dengan tabel yang lebih jelas.", style = MaterialTheme.typography.bodySmall) }
        }
    }
}
