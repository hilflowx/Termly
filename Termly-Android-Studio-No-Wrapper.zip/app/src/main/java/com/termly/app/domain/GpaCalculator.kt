package com.termly.app.domain

import com.termly.app.data.local.MataKuliahEntity
import com.termly.app.data.local.NilaiEntity
import com.termly.app.data.local.SemesterEntity

data class GradeScale(
    val weights: Map<String, Double> = mapOf("A" to 4.0, "B" to 3.0, "C" to 2.0, "D" to 1.0, "E" to 0.0)
) {
    fun weight(letter: String): Double? = weights[letter.trim().uppercase()]
}

enum class RepeatedGradeRule { HIGHEST, LATEST }

data class GradeRecord(val courseId: Long, val semesterId: Long, val letter: String, val credits: Int)

object GpaCalculator {
    fun ips(records: List<GradeRecord>, scale: GradeScale): Double? = weightedAverage(records, scale)

    fun ipk(records: List<GradeRecord>, scale: GradeScale, repeatedRule: RepeatedGradeRule = RepeatedGradeRule.HIGHEST): Double? {
        val effective = records.groupBy { it.courseId }.values.flatMap { attempts ->
            when (repeatedRule) {
                RepeatedGradeRule.HIGHEST -> listOfNotNull(attempts.maxByOrNull { scale.weight(it.letter) ?: Double.NEGATIVE_INFINITY })
                RepeatedGradeRule.LATEST -> listOfNotNull(attempts.maxByOrNull { it.semesterId })
            }
        }
        return weightedAverage(effective, scale)
    }

    fun allSemesterIps(
        grades: List<NilaiEntity>, subjects: List<MataKuliahEntity>, semesters: List<SemesterEntity>, scale: GradeScale
    ): Map<Long, Double?> {
        val subjectById = subjects.associateBy { it.id }
        val result = linkedMapOf<Long, Double?>()
        semesters.sortedBy { it.id }.forEach { semester ->
            val records = grades.filter { it.semesterId == semester.id }.mapNotNull { grade ->
                val subject = subjectById[grade.mataKuliahId] ?: return@mapNotNull null
                GradeRecord(subject.id, semester.id, grade.nilaiHuruf, subject.sks)
            }
            result[semester.id] = ips(records, scale)
        }
        return result
    }

    private fun weightedAverage(records: List<GradeRecord>, scale: GradeScale): Double? {
        var weighted = 0.0
        var credits = 0
        records.forEach { record ->
            val weight = scale.weight(record.letter) ?: return@forEach
            val sks = record.credits.coerceAtLeast(0)
            weighted += weight * sks
            credits += sks
        }
        return if (credits == 0) null else weighted / credits
    }
}
