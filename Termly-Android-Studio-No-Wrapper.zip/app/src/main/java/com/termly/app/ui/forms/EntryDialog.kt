package com.termly.app.ui.forms

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import com.termly.app.data.local.MataKuliahEntity
import com.termly.app.data.local.SesiRutinEntity
import java.time.LocalDate
import java.time.ZoneId
import java.time.LocalDateTime
import java.time.LocalTime

enum class EntryType { SUBJECT, SESSION, DEADLINE, GRADE }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntryDialog(
    type: EntryType,
    subjects: List<MataKuliahEntity>,
    routines: List<SesiRutinEntity>,
    onDismiss: () -> Unit,
    onSaveSubject: (String, Int, String) -> Unit,
    onSaveSession: (Long, Int, String, String, String, String, String, Long?) -> Unit,
    onSaveDeadline: (Long, String, Long) -> Unit,
    onSaveGrade: (Long, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var credits by remember { mutableStateOf("2") }
    var lecturer by remember { mutableStateOf("") }
    var selectedCourse by remember { mutableStateOf(subjects.firstOrNull()?.id ?: 0L) }
    var courseMenu by remember { mutableStateOf(false) }
    var day by remember { mutableIntStateOf(1) }
    var start by remember { mutableStateOf("08:00") }
    var end by remember { mutableStateOf("09:40") }
    var room by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var sessionType by remember { mutableStateOf("rutin") }
    var routineIdText by remember { mutableStateOf("") }
    var routineMenu by remember { mutableStateOf(false) }
    var deadlineDate by remember { mutableStateOf(LocalDate.now().plusDays(1).toString()) }
    var deadlineTime by remember { mutableStateOf("23:59") }
    var grade by remember { mutableStateOf("A") }
    var semester by remember { mutableStateOf("Semester 1") }
    var error by remember { mutableStateOf("") }

    val title = when (type) { EntryType.SUBJECT -> "Tambah mata kuliah"; EntryType.SESSION -> "Tambah sesi kuliah"; EntryType.DEADLINE -> "Tambah tugas / deadline"; EntryType.GRADE -> "Tambah nilai" }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 560.dp).verticalScroll(rememberScrollState()).imePadding(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (type) {
                    EntryType.SUBJECT -> {
                        OutlinedTextField(name, { name = it }, label = { Text("Nama mata kuliah") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(credits, { credits = it.filter(Char::isDigit).take(1) }, label = { Text("SKS (1–6)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(lecturer, { lecturer = it }, label = { Text("Dosen (opsional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    }
                    EntryType.SESSION -> {
                        if (subjects.isEmpty()) Text("Tambahkan mata kuliah terlebih dahulu di menu +.", color = MaterialTheme.colorScheme.error)
                        ExposedDropdownMenuBox(expanded = courseMenu, onExpandedChange = { courseMenu = it }) {
                            OutlinedTextField(subjects.firstOrNull { it.id == selectedCourse }?.nama.orEmpty(), { }, readOnly = true, label = { Text("Mata kuliah") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(courseMenu) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                            ExposedDropdownMenu(expanded = courseMenu, onDismissRequest = { courseMenu = false }) { subjects.forEach { s -> DropdownMenuItem(text = { Text(s.nama, maxLines = 1) }, onClick = { selectedCourse = s.id; courseMenu = false }) } }
                        }
                        Text("Jenis sesi", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("rutin" to "Rutin", "tambah" to "Tambahan", "pindah" to "Pindah", "batal" to "Batal").forEach { (v, label) -> FilterChip(selected = sessionType == v, onClick = { sessionType = v }, label = { Text(label) }) }
                        }
                        if (sessionType == "rutin") {
                            var dayMenu by remember { mutableStateOf(false) }
                            ExposedDropdownMenuBox(expanded = dayMenu, onExpandedChange = { dayMenu = it }) {
                                OutlinedTextField(listOf("", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu")[day], {}, readOnly = true, label = { Text("Hari") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(dayMenu) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                ExposedDropdownMenu(expanded = dayMenu, onDismissRequest = { dayMenu = false }) { (1..7).forEach { d -> DropdownMenuItem(text = { Text(listOf("", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu")[d]) }, onClick = { day = d; dayMenu = false }) } }
                            }
                        } else {
                            OutlinedTextField(date, { date = it }, label = { Text("Tanggal (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            if (sessionType == "pindah" || sessionType == "batal") {
                                val dateDay = runCatching { LocalDate.parse(date).dayOfWeek.value }.getOrDefault(-1)
                                val availableRoutines = routines.filter { it.hari == dateDay }
                                val targetRoutine = availableRoutines.firstOrNull { it.id.toString() == routineIdText }
                                ExposedDropdownMenuBox(expanded = routineMenu, onExpandedChange = { routineMenu = it }) {
                                    OutlinedTextField(
                                        value = targetRoutine?.let { routine -> "${subjects.firstOrNull { it.id == routine.mataKuliahId }?.nama ?: "Mata kuliah"} · ${routine.jamMulai}–${routine.jamSelesai}" } ?: "Pilih sesi rutin yang diganti",
                                        onValueChange = {}, readOnly = true, label = { Text("Sesi rutin") },
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(routineMenu) },
                                        modifier = Modifier.menuAnchor().fillMaxWidth()
                                    )
                                    ExposedDropdownMenu(expanded = routineMenu, onDismissRequest = { routineMenu = false }) {
                                        availableRoutines.forEach { routine ->
                                            DropdownMenuItem(
                                                text = { Text("${subjects.firstOrNull { it.id == routine.mataKuliahId }?.nama ?: "Mata kuliah"} · ${routine.jamMulai}–${routine.jamSelesai}", maxLines = 2) },
                                                onClick = { routineIdText = routine.id.toString(); selectedCourse = routine.mataKuliahId; routineMenu = false }
                                            )
                                        }
                                    }
                                }
                                if (availableRoutines.isEmpty()) Text("Belum ada sesi rutin pada hari tanggal tersebut.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(start, { start = it }, label = { Text("Mulai HH:mm") }, modifier = Modifier.weight(1f), singleLine = true)
                            OutlinedTextField(end, { end = it }, label = { Text("Selesai HH:mm") }, modifier = Modifier.weight(1f), singleLine = true)
                        }
                        OutlinedTextField(room, { room = it }, label = { Text("Ruang (opsional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    }
                    EntryType.DEADLINE -> {
                        if (subjects.isEmpty()) Text("Tambahkan mata kuliah terlebih dahulu di menu +.", color = MaterialTheme.colorScheme.error)
                        ExposedDropdownMenuBox(expanded = courseMenu, onExpandedChange = { courseMenu = it }) {
                            OutlinedTextField(subjects.firstOrNull { it.id == selectedCourse }?.nama.orEmpty(), { }, readOnly = true, label = { Text("Mata kuliah") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(courseMenu) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                            ExposedDropdownMenu(expanded = courseMenu, onDismissRequest = { courseMenu = false }) { subjects.forEach { s -> DropdownMenuItem(text = { Text(s.nama, maxLines = 1) }, onClick = { selectedCourse = s.id; courseMenu = false }) } }
                        }
                        OutlinedTextField(name, { name = it }, label = { Text("Judul tugas / deadline") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(deadlineDate, { deadlineDate = it }, label = { Text("Tanggal (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(deadlineTime, { deadlineTime = it }, label = { Text("Waktu (HH:mm)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    }
                    EntryType.GRADE -> {
                        if (subjects.isEmpty()) Text("Tambahkan mata kuliah terlebih dahulu di menu +.", color = MaterialTheme.colorScheme.error)
                        ExposedDropdownMenuBox(expanded = courseMenu, onExpandedChange = { courseMenu = it }) {
                            OutlinedTextField(subjects.firstOrNull { it.id == selectedCourse }?.nama.orEmpty(), { }, readOnly = true, label = { Text("Mata kuliah") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(courseMenu) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                            ExposedDropdownMenu(expanded = courseMenu, onDismissRequest = { courseMenu = false }) { subjects.forEach { s -> DropdownMenuItem(text = { Text(s.nama, maxLines = 1) }, onClick = { selectedCourse = s.id; courseMenu = false }) } }
                        }
                        OutlinedTextField(semester, { semester = it }, label = { Text("Semester") }, modifier = Modifier.fillMaxWidth())
                        var gradeMenu by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(expanded = gradeMenu, onExpandedChange = { gradeMenu = it }) {
                            OutlinedTextField(grade, {}, readOnly = true, label = { Text("Nilai huruf") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(gradeMenu) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                            ExposedDropdownMenu(expanded = gradeMenu, onDismissRequest = { gradeMenu = false }) { listOf("A", "B", "C", "D", "E").forEach { g -> DropdownMenuItem(text = { Text(g) }, onClick = { grade = g; gradeMenu = false }) } }
                        }
                    }
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            Button(onClick = {
                try {
                    when (type) {
                        EntryType.SUBJECT -> { if (name.isBlank()) error = "Nama mata kuliah wajib diisi." else { onSaveSubject(name, credits.toIntOrNull()?.coerceIn(1, 6) ?: 2, lecturer); onDismiss() } }
                        EntryType.SESSION -> {
                            val validTimeRange = runCatching {
                                val startTime = LocalTime.parse(start)
                                LocalTime.parse(end).isAfter(startTime)
                            }.getOrDefault(false)
                            if (selectedCourse == 0L) error = "Pilih mata kuliah terlebih dahulu."
                            else if (sessionType != "batal" && !validTimeRange) error = "Jam harus valid dan waktu selesai harus setelah waktu mulai."
                            else if (sessionType == "rutin") { onSaveSession(selectedCourse, day, start, end, room, "rutin", "", null); onDismiss() }
                            else {
                                LocalDate.parse(date)
                                if ((sessionType == "pindah" || sessionType == "batal") && routineIdText.isBlank()) error = "Pilih sesi rutin yang akan diganti."
                                else { onSaveSession(selectedCourse, day, start, end, room, sessionType, date, routineIdText.toLongOrNull()); onDismiss() }
                            }
                        }
                        EntryType.DEADLINE -> {
                            if (selectedCourse == 0L || name.isBlank()) error = "Mata kuliah dan judul wajib diisi."
                            else { val dt = LocalDateTime.of(LocalDate.parse(deadlineDate), LocalTime.parse(deadlineTime)); onSaveDeadline(selectedCourse, name, dt.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()); onDismiss() }
                        }
                        EntryType.GRADE -> if (selectedCourse == 0L) error = "Pilih mata kuliah terlebih dahulu." else { onSaveGrade(selectedCourse, semester, grade); onDismiss() }
                    }
                } catch (_: Exception) { error = "Periksa tanggal, jam, dan angka yang dimasukkan." }
            }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
