package com.termly.app.ui.previews

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.termly.app.data.local.DeadlineEntity
import com.termly.app.data.local.MataKuliahEntity
import com.termly.app.domain.ResolvedSession
import com.termly.app.domain.SessionKind
import com.termly.app.data.preferences.ProfileSettings
import com.termly.app.ui.screens.HomeScreen
import com.termly.app.ui.theme.TermlyTheme

private val previewSettings = ProfileSettings(
    name = "Mahasiswa Contoh", nim = "12345678", programStudi = "Teknik Informatika",
    fakultas = "Fakultas Ilmu Komputer", universitas = "Universitas", onboardingComplete = true
)
private val previewSubjects = listOf(
    MataKuliahEntity(id = 1, nama = "Pemrograman Mobile", sks = 3, dosen = "Dosen A"),
    MataKuliahEntity(id = 2, nama = "Basis Data", sks = 3, dosen = "Dosen B"),
    MataKuliahEntity(id = 3, nama = "Rekayasa Perangkat Lunak", sks = 2, dosen = "Dosen C")
)
private val previewSessions = listOf(
    ResolvedSession(courseId = 1, start = "08:00", end = "09:40", room = "Lab Mobile", kind = SessionKind.ROUTINE, sourceRoutineId = 1),
    ResolvedSession(courseId = 2, start = "10:00", end = "11:40", room = "B-204", kind = SessionKind.ROUTINE, sourceRoutineId = 2)
)
private val previewDeadlines = listOf(
    DeadlineEntity(id = 1, mataKuliahId = 1, judul = "Proyek akhir aplikasi manajemen perkuliahan", waktu = System.currentTimeMillis() + 10 * 60 * 60 * 1000),
    DeadlineEntity(id = 2, mataKuliahId = 2, judul = "Laporan praktikum basis data", waktu = System.currentTimeMillis() + 55 * 60 * 60 * 1000)
)

@Composable
private fun HomePreview(dark: Boolean = false) {
    TermlyTheme(themeMode = if (dark) "dark" else "light", dynamicColor = false) {
        HomeScreen(
            settings = previewSettings, subjects = previewSubjects, sessions = previewSessions,
            nextUpcoming = java.time.LocalDate.now() to previewSessions.first(), deadlines = previewDeadlines,
            ipk = 3.72, ips = 3.85, onAdd = {}, onTasks = {},
            onSchedule = {}, onValues = {}, onScroll = {}
        )
    }
}

@Preview(name = "Kecil 360 x 640", widthDp = 360, heightDp = 640, showBackground = true)
@Composable
private fun SmallPhonePreview() = HomePreview()

@Preview(name = "Standar 411 x 891", widthDp = 411, heightDp = 891, showBackground = true)
@Composable
private fun StandardPhonePreview() = HomePreview()

@Preview(name = "Tablet kecil", widthDp = 600, heightDp = 960, showBackground = true)
@Composable
private fun SmallTabletPreview() = HomePreview()

@Preview(name = "Font besar 1.3", widthDp = 360, heightDp = 720, fontScale = 1.3f, showBackground = true)
@Composable
private fun LargeFontPreview() = HomePreview()

@Preview(name = "Mode gelap", widthDp = 411, heightDp = 891, uiMode = android.content.res.Configuration.UI_MODE_NIGHT_YES, showBackground = true)
@Composable
private fun DarkPreview() = HomePreview(dark = true)
