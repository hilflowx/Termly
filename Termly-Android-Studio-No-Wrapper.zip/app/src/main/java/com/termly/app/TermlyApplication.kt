package com.termly.app

import android.app.Application
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.termly.app.data.local.TermlyDatabase
import com.termly.app.data.preferences.SettingsStore
import com.termly.app.data.repository.TermlyRepository

class TermlyApplication : Application() {
    val database by lazy { TermlyDatabase.getInstance(this) }
    val settingsStore by lazy { SettingsStore(this) }
    val repository by lazy { TermlyRepository(database) }

    override fun onCreate() {
        super.onCreate()
        PDFBoxResourceLoader.init(applicationContext)
    }
}
