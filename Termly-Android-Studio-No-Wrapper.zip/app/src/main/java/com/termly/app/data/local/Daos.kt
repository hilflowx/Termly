package com.termly.app.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MataKuliahDao {
    @Query("SELECT * FROM mata_kuliah ORDER BY nama COLLATE NOCASE") fun observeAll(): Flow<List<MataKuliahEntity>>
    @Query("SELECT * FROM mata_kuliah ORDER BY nama COLLATE NOCASE") suspend fun getAll(): List<MataKuliahEntity>
    @Query("SELECT * FROM mata_kuliah WHERE id = :id LIMIT 1") suspend fun getById(id: Long): MataKuliahEntity?
    @Query("SELECT * FROM mata_kuliah WHERE nama = :name COLLATE NOCASE LIMIT 1") suspend fun getByName(name: String): MataKuliahEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: MataKuliahEntity): Long
    @Delete suspend fun delete(item: MataKuliahEntity)
}

@Dao
interface SemesterDao {
    @Query("SELECT * FROM semester ORDER BY id") fun observeAll(): Flow<List<SemesterEntity>>
    @Query("SELECT * FROM semester ORDER BY id") suspend fun getAll(): List<SemesterEntity>
    @Query("SELECT * FROM semester WHERE label = :label LIMIT 1") suspend fun getByLabel(label: String): SemesterEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: SemesterEntity): Long
}

@Dao
interface NilaiDao {
    @Query("SELECT * FROM nilai ORDER BY semesterId, mataKuliahId") fun observeAll(): Flow<List<NilaiEntity>>
    @Query("SELECT * FROM nilai ORDER BY semesterId, mataKuliahId") suspend fun getAll(): List<NilaiEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: NilaiEntity): Long
    @Query("DELETE FROM nilai WHERE mataKuliahId = :courseId AND semesterId = :semesterId") suspend fun deleteForCourseSemester(courseId: Long, semesterId: Long)
}

@Dao
interface SesiRutinDao {
    @Query("SELECT * FROM sesi_rutin ORDER BY hari, jamMulai") fun observeAll(): Flow<List<SesiRutinEntity>>
    @Query("SELECT * FROM sesi_rutin ORDER BY hari, jamMulai") suspend fun getAll(): List<SesiRutinEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: SesiRutinEntity): Long
    @Delete suspend fun delete(item: SesiRutinEntity)
}

@Dao
interface SesiPengecualianDao {
    @Query("SELECT * FROM sesi_pengecualian ORDER BY tanggal, jamMulai") fun observeAll(): Flow<List<SesiPengecualianEntity>>
    @Query("SELECT * FROM sesi_pengecualian ORDER BY tanggal, jamMulai") suspend fun getAll(): List<SesiPengecualianEntity>
    @Query("SELECT * FROM sesi_pengecualian WHERE tanggal = :date ORDER BY jamMulai") suspend fun byDate(date: String): List<SesiPengecualianEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: SesiPengecualianEntity): Long
    @Query("DELETE FROM sesi_pengecualian WHERE id = :id") suspend fun deleteById(id: Long)
}

@Dao
interface DeadlineDao {
    @Query("SELECT * FROM deadline ORDER BY waktu") fun observeAll(): Flow<List<DeadlineEntity>>
    @Query("SELECT * FROM deadline ORDER BY waktu") suspend fun getAll(): List<DeadlineEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: DeadlineEntity): Long
    @Query("UPDATE deadline SET status = :done WHERE id = :id") suspend fun setDone(id: Long, done: Boolean)
    @Query("DELETE FROM deadline WHERE id = :id") suspend fun deleteById(id: Long)
}
