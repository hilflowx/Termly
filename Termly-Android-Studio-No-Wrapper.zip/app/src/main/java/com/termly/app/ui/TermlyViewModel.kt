package com.termly.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.termly.app.TermlyApplication
import com.termly.app.data.local.*
import com.termly.app.data.preferences.ProfileSettings
import com.termly.app.domain.GradeRecord
import com.termly.app.domain.GradeScale
import com.termly.app.domain.GpaCalculator
import com.termly.app.domain.RepeatedGradeRule
import com.termly.app.domain.ScheduleResolver
import com.termly.app.domain.ResolvedSession
import com.termly.app.util.ReminderScheduler
import com.termly.app.widget.TermlyWidget
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import org.json.JSONObject

class TermlyViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as TermlyApplication
    private val repo = app.repository
    private val settingsStore = app.settingsStore

    val subjects = repo.subjects.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val semesters = repo.semesters.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val grades = repo.grades.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val routines = repo.routines.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val exceptions = repo.exceptions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val deadlines = repo.deadlines.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val settings = settingsStore.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ProfileSettings())

    fun completeOnboarding() = viewModelScope.launch { settingsStore.setOnboardingComplete(true) }
    fun saveProfile(name: String, nim: String, prodi: String, fakultas: String, universitas: String) = viewModelScope.launch {
        settingsStore.updateProfile(name, nim, prodi, fakultas, universitas)
    }
    fun setTheme(mode: String) = viewModelScope.launch { settingsStore.setTheme(mode) }
    fun setDynamicColor(value: Boolean) = viewModelScope.launch { settingsStore.setDynamicColor(value) }
    fun setRepeatRule(value: String) = viewModelScope.launch { settingsStore.setRepeatRule(value) }
    fun setReminders(dayBefore: Boolean, hoursBefore: Int) = viewModelScope.launch { settingsStore.setReminders(dayBefore, hoursBefore) }
    fun setGradeWeights(a: Double, b: Double, c: Double, d: Double, e: Double) = viewModelScope.launch { settingsStore.setGradeWeights(a, b, c, d, e) }

    fun addSubject(name: String, credits: Int, lecturer: String) = viewModelScope.launch {
        repo.upsertSubject(name, credits, lecturer)
        TermlyWidget().updateAll(getApplication())
    }
    fun addRoutine(courseId: Long, day: Int, start: String, end: String, room: String) = viewModelScope.launch {
        repo.addRoutine(courseId, day, start, end, room)
        TermlyWidget().updateAll(getApplication())
    }
    fun addException(date: String, type: String, courseId: Long, start: String, end: String, room: String, routineId: Long? = null) = viewModelScope.launch {
        repo.addException(date, type, courseId, start, end, room, routineId)
        TermlyWidget().updateAll(getApplication())
    }
    fun addDeadline(courseId: Long, title: String, timeMillis: Long) = viewModelScope.launch {
        val id = repo.addDeadline(courseId, title, timeMillis)
        val setting = settings.value
        ReminderScheduler.schedule(getApplication(), DeadlineEntity(id, courseId, title, timeMillis), setting.reminderDayBefore, setting.reminderHoursBefore)
        TermlyWidget().updateAll(getApplication())
    }
    fun toggleDeadline(id: Long, done: Boolean) = viewModelScope.launch {
        val existing = deadlines.value.firstOrNull { it.id == id }
        if (existing != null && done) ReminderScheduler.cancel(getApplication(), existing)
        repo.markDeadline(id, done)
        if (existing != null && !done) ReminderScheduler.schedule(getApplication(), existing.copy(status = false), settings.value.reminderDayBefore, settings.value.reminderHoursBefore)
        TermlyWidget().updateAll(getApplication())
    }
    fun deleteDeadline(id: Long) = viewModelScope.launch {
        deadlines.value.firstOrNull { it.id == id }?.let { ReminderScheduler.cancel(getApplication(), it) }
        repo.deleteDeadline(id)
        TermlyWidget().updateAll(getApplication())
    }
    fun addGrade(courseId: Long, semesterLabel: String, letter: String) = viewModelScope.launch {
        val semesterId = repo.addSemester(semesterLabel)
        repo.addGrade(courseId, semesterId, letter)
    }

    fun restoreBackup(json: String, onResult: (String) -> Unit) = viewModelScope.launch {
        runCatching {
            val root = JSONObject(json)
            repo.restoreBackup(json)
            val profile = root.optJSONObject("profile")
            if (profile != null) {
                settingsStore.restore(ProfileSettings(
                    name = profile.optString("name", "Mahasiswa"), nim = profile.optString("nim"),
                    programStudi = profile.optString("programStudi"), fakultas = profile.optString("fakultas"),
                    universitas = profile.optString("universitas"), themeMode = profile.optString("themeMode", "system"),
                    dynamicColor = profile.optBoolean("dynamicColor", false), onboardingComplete = profile.optBoolean("onboardingComplete", true),
                    repeatedGradeRule = profile.optString("repeatedGradeRule", "highest"),
                    reminderDayBefore = profile.optBoolean("reminderDayBefore", true), reminderHoursBefore = profile.optInt("reminderHoursBefore", 3),
                    bobotA = profile.optDouble("bobotA", 4.0), bobotB = profile.optDouble("bobotB", 3.0),
                    bobotC = profile.optDouble("bobotC", 2.0), bobotD = profile.optDouble("bobotD", 1.0), bobotE = profile.optDouble("bobotE", 0.0)
                ))
            }
        }.onSuccess {
            TermlyWidget().updateAll(getApplication())
            onResult("Cadangan berhasil dipulihkan.")
        }.onFailure { onResult("Pemulihan gagal: ${it.message ?: "format file tidak valid"}") }
    }

    fun resolvedSessions(date: LocalDate): List<ResolvedSession> = ScheduleResolver.resolve(date, routines.value, exceptions.value)

    fun nextUpcomingSession(from: LocalDate = LocalDate.now()): Pair<LocalDate, ResolvedSession>? {
        val now = java.time.LocalTime.now()
        return (0L..7L).asSequence().mapNotNull { offset ->
            val day = from.plusDays(offset)
            ScheduleResolver.resolve(day, routines.value, exceptions.value)
                .filter { it.kind != com.termly.app.domain.SessionKind.CANCELLED }
                .filter { offset > 0 || runCatching { java.time.LocalTime.parse(it.start).isAfter(now) }.getOrDefault(false) }
                .minByOrNull { it.start }?.let { day to it }
        }.firstOrNull()
    }

    fun gradeScale(): GradeScale = GradeScale(mapOf(
        "A" to settings.value.bobotA, "B" to settings.value.bobotB, "C" to settings.value.bobotC,
        "D" to settings.value.bobotD, "E" to settings.value.bobotE
    ))
    fun ipk(): Double? {
        val subjectMap = subjects.value.associateBy { it.id }
        val records = grades.value.mapNotNull { grade ->
            val sub = subjectMap[grade.mataKuliahId] ?: return@mapNotNull null
            GradeRecord(sub.id, grade.semesterId, grade.nilaiHuruf, sub.sks)
        }
        return GpaCalculator.ipk(records, gradeScale(), if (settings.value.repeatedGradeRule == "latest") RepeatedGradeRule.LATEST else RepeatedGradeRule.HIGHEST)
    }
    fun semesterIps(semesterId: Long): Double? {
        val subjectMap = subjects.value.associateBy { it.id }
        val records = grades.value.filter { it.semesterId == semesterId }.mapNotNull { grade ->
            val sub = subjectMap[grade.mataKuliahId] ?: return@mapNotNull null
            GradeRecord(sub.id, semesterId, grade.nilaiHuruf, sub.sks)
        }
        return GpaCalculator.ips(records, gradeScale())
    }

    fun simulateIpk(letter: String, credits: Int): Double? {
        val subjectMap = subjects.value.associateBy { it.id }
        val records = grades.value.mapNotNull { grade ->
            val subject = subjectMap[grade.mataKuliahId] ?: return@mapNotNull null
            GradeRecord(subject.id, grade.semesterId, grade.nilaiHuruf, subject.sks)
        }
        val nextSemesterId = (semesters.value.maxOfOrNull { it.id } ?: 0L) + 1L
        val simulated = GradeRecord(Long.MIN_VALUE, nextSemesterId, letter, credits.coerceIn(1, 6))
        val rule = if (settings.value.repeatedGradeRule == "latest") RepeatedGradeRule.LATEST else RepeatedGradeRule.HIGHEST
        return GpaCalculator.ipk(records + simulated, gradeScale(), rule)
    }

    suspend fun importRows(rows: List<com.termly.app.ui.importing.ImportPreviewRow>, kind: String, semesterLabel: String) {
        rows.forEach { row ->
            if (row.name.isBlank()) return@forEach
            val courseId = repo.importSubject(row.name, row.sks.coerceIn(1, 6))
            if (kind == "khs" && row.grade.isNotBlank()) repo.addGrade(courseId, repo.addSemester(semesterLabel.ifBlank { "Semester 1" }), row.grade)
            val startTime = runCatching { java.time.LocalTime.parse(row.start) }.getOrNull()
            val endTime = runCatching { java.time.LocalTime.parse(row.end) }.getOrNull()
            if (kind == "krs" && row.day in 1..7 && startTime != null && endTime != null && endTime.isAfter(startTime)) {
                repo.addRoutine(courseId, row.day, row.start, row.end, row.room)
            }
        }
        TermlyWidget().updateAll(getApplication())
    }

    companion object {
        fun factory(app: TermlyApplication): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = TermlyViewModel(app) as T
        }
    }
}
