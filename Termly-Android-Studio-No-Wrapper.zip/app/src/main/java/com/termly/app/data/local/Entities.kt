package com.termly.app.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "mata_kuliah", indices = [Index(value = ["nama"], unique = true)])
data class MataKuliahEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nama: String,
    val sks: Int = 2,
    val dosen: String = ""
)

@Entity(tableName = "semester", indices = [Index(value = ["label"], unique = true)])
data class SemesterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val label: String
)

@Entity(tableName = "nilai", indices = [Index(value = ["mataKuliahId", "semesterId"], unique = true)])
data class NilaiEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mataKuliahId: Long,
    val semesterId: Long,
    val nilaiHuruf: String
)

@Entity(tableName = "sesi_rutin", indices = [Index(value = ["hari", "jamMulai"])])
data class SesiRutinEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mataKuliahId: Long,
    /** ISO weekday: Monday=1 through Sunday=7. */
    val hari: Int,
    val jamMulai: String,
    val jamSelesai: String,
    val ruang: String = ""
)

@Entity(tableName = "sesi_pengecualian", indices = [Index(value = ["tanggal"])])
data class SesiPengecualianEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tanggal: String,
    /** tambah, pindah, batal */
    val jenis: String,
    val mataKuliahId: Long,
    val jamMulai: String = "",
    val jamSelesai: String = "",
    val ruang: String = "",
    /** Links move/cancel exceptions to the routine session they replace. */
    val routineSessionId: Long? = null
)

@Entity(tableName = "deadline", indices = [Index(value = ["waktu"])])
data class DeadlineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mataKuliahId: Long,
    val judul: String,
    val waktu: Long,
    val status: Boolean = false,
    val pengingatAktif: Boolean = true
)
