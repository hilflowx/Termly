package com.termly.app.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.flow.collect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.termly.app.data.local.*
import com.termly.app.data.preferences.ProfileSettings
import com.termly.app.domain.ResolvedSession
import com.termly.app.domain.ScheduleResolver
import com.termly.app.domain.SessionKind
import com.termly.app.ui.components.*
import com.termly.app.ui.theme.*
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun ScrollAwareList(
    modifier: Modifier = Modifier,
    onScrollDirection: (Boolean) -> Unit,
    contentPadding: PaddingValues = PaddingValues(bottom = 110.dp),
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit
) {
    val state = rememberLazyListState()
    LaunchedEffect(state) {
        var oldIndex = state.firstVisibleItemIndex
        var oldOffset = state.firstVisibleItemScrollOffset
        snapshotFlow { state.firstVisibleItemIndex to state.firstVisibleItemScrollOffset }.collect { (index, offset) ->
            val down = index > oldIndex || (index == oldIndex && offset > oldOffset + 2)
            val up = index < oldIndex || (index == oldIndex && offset < oldOffset - 2)
            if (down) onScrollDirection(false) else if (up) onScrollDirection(true)
            oldIndex = index; oldOffset = offset
        }
    }
    LazyColumn(modifier = modifier.fillMaxSize(), state = state, contentPadding = contentPadding, verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}

@Composable
fun HomeScreen(
    settings: ProfileSettings, subjects: List<MataKuliahEntity>, sessions: List<ResolvedSession>, nextUpcoming: Pair<LocalDate, ResolvedSession>?,
    deadlines: List<DeadlineEntity>, ipk: Double?, ips: Double?, onAdd: () -> Unit, onTasks: () -> Unit,
    onSchedule: () -> Unit, onValues: () -> Unit, onScroll: (Boolean) -> Unit
) {
    val today = LocalDate.now()
    val todaySessions = sessions.filter { it.kind != SessionKind.CANCELLED }.sortedBy { it.start }
    val subjectMap = subjects.associateBy { it.id }
    val nextDate = nextUpcoming?.first
    val next = nextUpcoming?.second
    ScrollAwareList(modifier = Modifier.padding(horizontal = 16.dp), onScrollDirection = onScroll) {
        item { Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Text("Halo, ${settings.name.ifBlank { "Mahasiswa" }}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(today.format(DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy", Locale("id", "ID"))).replaceFirstChar { it.uppercase() }, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } }
        item {
            TermlyCard() {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("KULIAH BERIKUTNYA", color = Teal, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(next?.let { subjectMap[it.courseId]?.nama } ?: "Tidak ada kelas berikutnya", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(6.dp))
                        Text(next?.let { "${if (nextDate == today) "Hari ini" else nextDate?.format(DateTimeFormatter.ofPattern("EEE, dd MMM", Locale("id", "ID")))} · ${it.start}–${it.end} · ${it.room.ifBlank { "Ruang belum diisi" }}" } ?: "Tambah jadwal agar ringkasan tampil di sini", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        if (next != null && nextDate == today) {
                            val minutes = runCatching { java.time.Duration.between(LocalTime.now(), LocalTime.parse(next.start)).toMinutes().coerceAtLeast(0) }.getOrDefault(0)
                            Text(if (minutes >= 60) "Mulai dalam ${minutes / 60} jam ${minutes % 60} menit" else "Mulai dalam $minutes menit", style = MaterialTheme.typography.labelMedium, color = Teal)
                        }
                    }
                    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.secondaryContainer) { Icon(Icons.Outlined.School, null, modifier = Modifier.padding(12.dp), tint = Teal) }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = onSchedule, modifier = Modifier.fillMaxWidth().heightIn(min = 44.dp)) { Text("Lihat jadwal") }
            }
        }
        item { SectionHeader("Timeline hari ini", "Buka jadwal", onSchedule) }
        if (todaySessions.isEmpty()) item { EmptyState("Hari ini lebih longgar", "Belum ada kuliah rutin yang tercatat untuk hari ini.", "Tambah sesi", onAdd) }
        items(todaySessions.take(6), key = { "home-session-${it.sourceRoutineId}-${it.sourceExceptionId}-${it.start}" }) { session ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(56.dp)) {
                    Text(session.start, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    Box(Modifier.padding(top = 5.dp).size(8.dp).background(Teal, CircleShape))
                }
                Spacer(Modifier.width(8.dp))
                TermlyCard(Modifier.weight(1f)) {
                    Text(subjectMap[session.courseId]?.nama ?: "Mata kuliah", fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text("${session.start}–${session.end} · ${session.room.ifBlank { "Ruang belum diisi" }}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { SectionHeader("Deadline terdekat", "Semua tugas", onTasks) }
        val upcoming = deadlines.filter { !it.status }.sortedBy { it.waktu }.take(3)
        if (upcoming.isEmpty()) item { Text("Belum ada deadline aktif. Tambahkan tugas supaya tidak terlewat.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium) }
        items(upcoming, key = { "home-deadline-${it.id}" }) { deadline ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(deadline.judul, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text("${subjectMap[deadline.mataKuliahId]?.nama ?: "Mata kuliah"} · ${formatDateTime(deadline.waktu)}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                }
                DeadlineTone(deadline.waktu, deadline.status)
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        }
        item { SectionHeader("Ringkasan nilai") }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TermlyCard(Modifier.weight(1f)) {
                    Text("IPK", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    AnimatedGpa(ipk, MaterialTheme.typography.headlineLarge, Teal)
                    Text("Kumulatif", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TermlyCard(Modifier.weight(1f)) {
                    Text("IPS terakhir", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    AnimatedGpa(ips, MaterialTheme.typography.headlineLarge, Amber)
                    Text("Per semester", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun ScheduleScreen(
    date: LocalDate, onDateChange: (LocalDate) -> Unit, routines: List<SesiRutinEntity>, exceptions: List<SesiPengecualianEntity>, sessions: List<ResolvedSession>, subjects: List<MataKuliahEntity>,
    viewMode: String, onViewModeChange: (String) -> Unit, onAdd: () -> Unit, onScroll: (Boolean) -> Unit
) {
    val subjectMap = subjects.associateBy { it.id }
    val weekStart = date.minusDays((date.dayOfWeek.value - 1).toLong())
    val displayedSessions = if (viewMode == "week") (0..6).flatMap { offset ->
        val dayDate = weekStart.plusDays(offset.toLong())
        ScheduleResolver.resolve(dayDate, routines, exceptions).map { dayDate to it }
    } else sessions.map { date to it }
    ScrollAwareList(modifier = Modifier.padding(horizontal = 16.dp), onScrollDirection = onScroll) {
        item { Text("Jadwal", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (0..6).forEach { offset ->
                    val d = weekStart.plusDays(offset.toLong())
                    val selected = d == date
                    Surface(onClick = { onDateChange(d) }, color = if (selected) Teal else MaterialTheme.colorScheme.surface, contentColor = if (selected) Color.White else MaterialTheme.colorScheme.onSurface, shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f)) {
                        Column(Modifier.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(d.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, Locale("id", "ID")), style = MaterialTheme.typography.labelSmall, maxLines = 1, color = if (selected) Color.White else if (d == LocalDate.now()) Amber else MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(d.dayOfMonth.toString(), fontWeight = FontWeight.Bold, color = if (selected) Color.White else if (d == LocalDate.now()) Teal else MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(date.format(DateTimeFormatter.ofPattern("EEEE, dd MMM", Locale("id", "ID"))).replaceFirstChar { it.uppercase() }, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                SingleChoiceSegmentedButtonRow {
                    SegmentedButton(selected = viewMode == "day", onClick = { onViewModeChange("day") }, shape = SegmentedButtonDefaults.itemShape(0)) { Text("Hari") }
                    SegmentedButton(selected = viewMode == "week", onClick = { onViewModeChange("week") }, shape = SegmentedButtonDefaults.itemShape(1)) { Text("Minggu") }
                }
            }
        }
        if (displayedSessions.isEmpty()) item { EmptyState(if (viewMode == "week") "Belum ada sesi minggu ini" else "Belum ada sesi", "Tambahkan jadwal rutin atau sesi khusus untuk tanggal ini.", "Tambah sesi", onAdd) }
        items(displayedSessions, key = { "session-${it.first}-${it.second.sourceRoutineId}-${it.second.sourceExceptionId}-${it.second.start}-${it.second.kind}" }) { (sessionDate, session) ->
            val accent = when (session.kind) { SessionKind.ROUTINE -> Teal; SessionKind.ADDED -> Amber; SessionKind.MOVED -> Purple; SessionKind.CANCELLED -> Muted }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.width(64.dp)) {
                    if (viewMode == "week") Text(sessionDate.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, Locale("id", "ID")), fontWeight = FontWeight.Medium, style = MaterialTheme.typography.labelSmall, color = if (sessionDate == LocalDate.now()) Teal else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    Text(session.start.ifBlank { "—" }, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                    Text(session.end, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.width(8.dp))
                Row(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(4.dp).heightIn(min = 54.dp).background(accent, RoundedCornerShape(4.dp)))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(subjectMap[session.courseId]?.nama ?: "Mata kuliah", fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, textDecoration = if (session.kind == SessionKind.CANCELLED) TextDecoration.LineThrough else TextDecoration.None)
                        Text(session.room.ifBlank { "Ruang belum diisi" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Surface(color = accent.copy(alpha = 0.12f), contentColor = accent, shape = RoundedCornerShape(50)) {
                        Text(when (session.kind) { SessionKind.ROUTINE -> "Rutin"; SessionKind.ADDED -> "Tambahan"; SessionKind.MOVED -> "Pindah"; SessionKind.CANCELLED -> "Batal" }, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                    }
                }
            }
        }
        item { Text("Catatan: perubahan bertanggal tidak mengubah jadwal rutin.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TasksScreen(deadlines: List<DeadlineEntity>, subjects: List<MataKuliahEntity>, onToggle: (Long, Boolean) -> Unit, onDelete: (Long) -> Unit, onAdd: () -> Unit, onScroll: (Boolean) -> Unit) {
    var filter by remember { mutableStateOf("Semua") }
    val subjectMap = subjects.associateBy { it.id }
    val now = System.currentTimeMillis()
    val filtered = deadlines.filter { deadline -> when (filter) {
        "Belum selesai" -> !deadline.status && deadline.waktu >= now
        "Selesai" -> deadline.status
        "Terlambat" -> !deadline.status && deadline.waktu < now
        else -> true
    } }.sortedBy { it.waktu }
    ScrollAwareList(modifier = Modifier.padding(horizontal = 16.dp), onScrollDirection = onScroll) {
        item { Text("Tugas & deadline", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("Semua", "Belum selesai", "Selesai", "Terlambat").forEach { choice ->
                    FilterChip(selected = filter == choice, onClick = { filter = choice }, label = { Text(choice, maxLines = 1) })
                }
            }
        }
        if (filtered.isEmpty()) item { EmptyState("Tidak ada tugas", "Tugas yang dibuat akan dikelompokkan berdasarkan waktu deadline.", "Tambah deadline", onAdd) }
        val sections = filtered.groupBy { item ->
            val day = java.time.Instant.ofEpochMilli(item.waktu).atZone(ZoneId.systemDefault()).toLocalDate()
            when {
                item.status -> "Selesai"
                item.waktu < now -> "Terlambat"
                day == LocalDate.now() -> "Hari ini"
                day == LocalDate.now().plusDays(1) -> "Besok"
                !day.isAfter(LocalDate.now().plusDays(7)) -> "Minggu ini"
                else -> "Deadline berikutnya"
            }
        }
        sections.forEach { (section, items) ->
            item { SectionHeader(section) }
            items(items, key = { "task-${it.id}" }) { deadline ->
                var drag by remember { mutableFloatStateOf(0f) }
                Row(Modifier.fillMaxWidth().pointerInput(deadline.id, deadline.status) {
                    detectHorizontalDragGestures(onHorizontalDrag = { _, amount -> drag += amount }, onDragEnd = { if (drag > 72f) onToggle(deadline.id, true); if (drag < -72f) onToggle(deadline.id, false); drag = 0f })
                }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = deadline.status, onCheckedChange = { onToggle(deadline.id, it) }, modifier = Modifier.size(48.dp))
                    Column(Modifier.weight(1f).clickable { onToggle(deadline.id, !deadline.status) }.padding(vertical = 8.dp)) {
                        Text(deadline.judul, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis, textDecoration = if (deadline.status) TextDecoration.LineThrough else TextDecoration.None)
                        Text("${subjectMap[deadline.mataKuliahId]?.nama ?: "Mata kuliah"} · ${formatDateTime(deadline.waktu)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        DeadlineTone(deadline.waktu, deadline.status)
                        IconButton(onClick = { onDelete(deadline.id) }, modifier = Modifier.size(40.dp)) { Icon(Icons.Outlined.DeleteOutline, contentDescription = "Hapus tugas", tint = Muted) }
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            }
        }
    }
}

@Composable
fun GradesScreen(subjects: List<MataKuliahEntity>, semesters: List<SemesterEntity>, grades: List<NilaiEntity>, ipk: Double?, semesterIps: (Long) -> Double?, simulateIpk: (String, Int) -> Double?, onAdd: () -> Unit, onScroll: (Boolean) -> Unit) {
    var expanded by remember { mutableStateOf(setOf<Long>()) }
    var simulatedGrade by remember { mutableStateOf("A") }
    var simulatedCredits by remember { mutableStateOf("3") }
    val subjectMap = subjects.associateBy { it.id }
    ScrollAwareList(modifier = Modifier.padding(horizontal = 16.dp), onScrollDirection = onScroll) {
        item { Text("Nilai akademik", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
        item {
            TermlyCard {
                Text("IPK Kumulatif", color = MaterialTheme.colorScheme.onSurfaceVariant)
                AnimatedGpa(ipk, MaterialTheme.typography.displayMedium, Teal)
                Text("Rata-rata berbobot SKS dari nilai yang sudah tersimpan", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            TermlyCard {
                SectionHeader("Simulasi IPK")
                Text("Perkirakan IPK jika mendapat nilai tertentu pada mata kuliah tambahan.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    listOf("A", "B", "C", "D", "E").forEach { letter ->
                        FilterChip(selected = simulatedGrade == letter, onClick = { simulatedGrade = letter }, label = { Text(letter) })
                    }
                }
                OutlinedTextField(
                    value = simulatedCredits,
                    onValueChange = { simulatedCredits = it.filter(Char::isDigit).take(1) },
                    label = { Text("SKS simulasi (1–6)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                val forecastCredits = simulatedCredits.toIntOrNull()?.coerceIn(1, 6) ?: 0
                val forecast = if (forecastCredits > 0) simulateIpk(simulatedGrade, forecastCredits) else null
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Perkiraan IPK", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Nilai $simulatedGrade · $forecastCredits SKS", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(forecast?.let { String.format(Locale.US, "%.2f", it) } ?: "—", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = Teal)
                }
            }
        }
        item { SectionHeader("Tren IPS per semester") }
        item {
            val values = semesters.mapNotNull { semester -> semesterIps(semester.id)?.let { semester.label to it } }
            TermlyCard {
                if (values.isEmpty()) Text("Grafik akan muncul setelah nilai semester dimasukkan.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                else {
                    Canvas(Modifier.fillMaxWidth().heightIn(min = 140.dp).height(160.dp)) {
                        val left = 18.dp.toPx(); val right = size.width - 18.dp.toPx(); val top = 12.dp.toPx(); val bottom = size.height - 25.dp.toPx()
                        val points = values.mapIndexed { index, entry ->
                            val x = if (values.size == 1) (left + right) / 2 else left + (right - left) * index / (values.size - 1)
                            val y = bottom - ((entry.second.coerceIn(0.0, 4.0) / 4.0).toFloat() * (bottom - top))
                            androidx.compose.ui.geometry.Offset(x, y)
                        }
                        for (level in 0..4) {
                            val y = bottom - (level / 4f) * (bottom - top)
                            drawLine(Color.LightGray.copy(alpha = 0.45f), androidx.compose.ui.geometry.Offset(left, y), androidx.compose.ui.geometry.Offset(right, y), strokeWidth = 1.dp.toPx())
                        }
                        points.zipWithNext().forEach { (a, b) -> drawLine(Teal, a, b, strokeWidth = 3.dp.toPx()) }
                        points.forEach { drawCircle(Amber, radius = 4.dp.toPx(), center = it) }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { values.forEach { Text(it.first, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)) } }
                }
            }
        }
        item { SectionHeader("Daftar semester") }
        if (semesters.isEmpty()) item { EmptyState("Belum ada nilai", "Input nilai atau impor KHS untuk menghitung IPS dan IPK.", "Tambah nilai", onAdd) }
        items(semesters, key = { "semester-${it.id}" }) { semester ->
            val list = grades.filter { it.semesterId == semester.id }
            TermlyCard {
                Row(Modifier.fillMaxWidth().clickable { expanded = if (semester.id in expanded) expanded - semester.id else expanded + semester.id }, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(semester.label, fontWeight = FontWeight.Bold); Text("${list.size} mata kuliah", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall) }
                    Column(horizontalAlignment = Alignment.End) { Text(semesterIps(semester.id)?.let { String.format(Locale.US, "%.2f", it) } ?: "—", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Teal); Text("IPS", style = MaterialTheme.typography.labelSmall) }
                    Icon(if (semester.id in expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = if (semester.id in expanded) "Tutup semester" else "Buka semester")
                }
                if (semester.id in expanded) {
                    HorizontalDivider(Modifier.padding(vertical = 10.dp))
                    list.forEach { grade ->
                        val subject = subjectMap[grade.mataKuliahId]
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text(subject?.nama ?: "Mata kuliah", fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis); Text("${subject?.sks ?: 0} SKS", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            Surface(color = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer, shape = RoundedCornerShape(10.dp)) { Text(grade.nilaiHuruf, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(settings: ProfileSettings, onEdit: () -> Unit, onImport: () -> Unit, onSettings: () -> Unit, onCourses: () -> Unit, onBackup: () -> Unit, onScroll: (Boolean) -> Unit) {
    ScrollAwareList(modifier = Modifier.padding(horizontal = 16.dp), onScrollDirection = onScroll) {
        item { Text("Profil", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
        item {
            TermlyCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(64.dp).background(Teal, CircleShape), contentAlignment = Alignment.Center) { Text(settings.name.split(" ").take(2).mapNotNull { it.firstOrNull() }.joinToString("").uppercase().ifBlank { "M" }, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) { Text(settings.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis); Text(settings.programStudi.ifBlank { "Program studi belum diisi" }, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                    IconButton(onClick = onEdit) { Icon(Icons.Outlined.Edit, contentDescription = "Edit profil") }
                }
                HorizontalDivider(Modifier.padding(vertical = 14.dp))
                ProfileData("NIM", settings.nim)
                ProfileData("Fakultas", settings.fakultas)
                ProfileData("Universitas", settings.universitas)
            }
        }
        item { SectionHeader("Kelola aplikasi") }
        item { ProfileMenuRow(Icons.Outlined.LibraryBooks, "Mata kuliah", "Daftar dan data mata kuliah", onCourses) }
        item { ProfileMenuRow(Icons.Outlined.FileOpen, "Impor KRS / KHS", "Baca PDF atau foto dengan pratinjau", onImport) }
        item { ProfileMenuRow(Icons.Outlined.Settings, "Pengaturan", "Tema, bobot nilai, dan pengingat", onSettings) }
        item { ProfileMenuRow(Icons.Outlined.Backup, "Cadangan & pemulihan", "Ekspor atau pulihkan data lokal", onBackup) }
        item { Text("Data disimpan di perangkat. Cadangan perlu diekspor secara manual agar bisa dipindahkan ke perangkat lain.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun ProfileData(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.widthIn(min = 90.dp)); Text(value.ifBlank { "Belum diisi" }, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis) }
}

@Composable
private fun ProfileMenuRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = Teal, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis) }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Muted)
    }
}

@Composable
fun CoursesScreen(subjects: List<MataKuliahEntity>, onAdd: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, contentDescription = "Kembali") }
            Text("Mata kuliah", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = onAdd) { Icon(Icons.Default.Add, contentDescription = "Tambah mata kuliah") }
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (subjects.isEmpty()) item { EmptyState("Daftar masih kosong", "Tambahkan mata kuliah secara manual atau impor KRS.", "Tambah mata kuliah", onAdd) }
            items(subjects, key = { it.id }) { subject -> TermlyCard {
                Text(subject.nama, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${subject.sks} SKS${if (subject.dosen.isBlank()) "" else " · ${subject.dosen}"}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            } }
        }
    }
}

@Composable
fun SettingsScreen(settings: ProfileSettings, onBack: () -> Unit, onTheme: (String) -> Unit, onDynamic: (Boolean) -> Unit, onRepeatRule: (String) -> Unit, onReminders: (Boolean, Int) -> Unit, onWeights: (Double, Double, Double, Double, Double) -> Unit, onBackup: () -> Unit, onExactAlarm: () -> Unit) {
    var a by remember(settings.bobotA) { mutableStateOf(settings.bobotA.toString()) }
    var b by remember(settings.bobotB) { mutableStateOf(settings.bobotB.toString()) }
    var c by remember(settings.bobotC) { mutableStateOf(settings.bobotC.toString()) }
    var d by remember(settings.bobotD) { mutableStateOf(settings.bobotD.toString()) }
    var e by remember(settings.bobotE) { mutableStateOf(settings.bobotE.toString()) }
    var dayBefore by remember(settings.reminderDayBefore) { mutableStateOf(settings.reminderDayBefore) }
    var reminderHours by remember(settings.reminderHoursBefore) { mutableIntStateOf(settings.reminderHoursBefore) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp).verticalScroll(rememberScrollState()).imePadding().padding(bottom = 24.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, contentDescription = "Kembali") }; Text("Pengaturan", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        TermlyCard {
            SectionHeader("Tampilan")
            listOf("system" to "Ikuti sistem", "light" to "Terang", "dark" to "Gelap").forEach { (v, label) -> Row(Modifier.fillMaxWidth().clickable { onTheme(v) }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(selected = settings.themeMode == v, onClick = { onTheme(v) }); Text(label) } }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Dynamic Color", fontWeight = FontWeight.Medium); Text("Warna mengikuti wallpaper perangkat", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Switch(checked = settings.dynamicColor, onCheckedChange = onDynamic) }
        }
        Spacer(Modifier.height(12.dp))
        TermlyCard {
            SectionHeader("Skala nilai")
            Text("Bobot bisa disesuaikan dengan aturan kampus.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                WeightField("A", a, { a = it }, Modifier.weight(1f)); WeightField("B", b, { b = it }, Modifier.weight(1f)); WeightField("C", c, { c = it }, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { WeightField("D", d, { d = it }, Modifier.weight(1f)); WeightField("E", e, { e = it }, Modifier.weight(1f)); Spacer(Modifier.weight(1f)) }
            Button(onClick = { onWeights(a.toDoubleOrNull() ?: 4.0, b.toDoubleOrNull() ?: 3.0, c.toDoubleOrNull() ?: 2.0, d.toDoubleOrNull() ?: 1.0, e.toDoubleOrNull() ?: 0.0) }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Simpan bobot nilai") }
            Spacer(Modifier.height(8.dp))
            Text("Mata kuliah diulang", fontWeight = FontWeight.Medium)
            listOf("highest" to "Pakai nilai tertinggi", "latest" to "Pakai nilai terbaru").forEach { (v, label) -> Row(Modifier.fillMaxWidth().clickable { onRepeatRule(v) }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(settings.repeatedGradeRule == v, onClick = { onRepeatRule(v) }); Text(label) } }
        }
        Spacer(Modifier.height(12.dp))
        TermlyCard {
            SectionHeader("Pengingat deadline")
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("H-1 sebelum deadline"); Text("Pengingat sehari sebelumnya", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Switch(dayBefore, { dayBefore = it; onReminders(it, reminderHours) }) }
            Text("Pengingat tambahan: ${reminderHours} jam sebelumnya", fontWeight = FontWeight.Medium)
            Slider(value = reminderHours.toFloat(), onValueChange = { reminderHours = it.toInt().coerceIn(1, 48) }, valueRange = 1f..48f, steps = 46)
            Button(onClick = { onReminders(dayBefore, reminderHours) }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Simpan pengingat") }
            Text("Alarm presisi dipakai jika diizinkan sistem. Jika tidak, Termly memakai alarm yang diizinkan Android.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onExactAlarm, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Buka izin alarm presisi") }
        }
        Spacer(Modifier.height(12.dp))
        TermlyCard { SectionHeader("Data lokal"); Text("Gunakan cadangan untuk memindahkan data ke perangkat lain.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant); Button(onClick = onBackup, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Cadangan & pemulihan") } }
    }
}

@Composable
private fun WeightField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(value, onChange, label = { Text(label) }, modifier = modifier, singleLine = true, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Decimal))
}

@Composable
fun ProfileEditDialog(settings: ProfileSettings, onDismiss: () -> Unit, onSave: (String, String, String, String, String) -> Unit) {
    var name by remember { mutableStateOf(settings.name) }; var nim by remember { mutableStateOf(settings.nim) }
    var prodi by remember { mutableStateOf(settings.programStudi) }; var fakultas by remember { mutableStateOf(settings.fakultas) }; var university by remember { mutableStateOf(settings.universitas) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Edit profil akademik") }, text = {
        Column(Modifier.fillMaxWidth().heightIn(max = 460.dp).verticalScroll(rememberScrollState()).imePadding(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Nama") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(nim, { nim = it }, label = { Text("NIM") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(prodi, { prodi = it }, label = { Text("Program studi") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(fakultas, { fakultas = it }, label = { Text("Fakultas") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(university, { university = it }, label = { Text("Universitas") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        }
    }, confirmButton = { Button(onClick = { onSave(name, nim, prodi, fakultas, university); onDismiss() }) { Text("Simpan") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } })
}

@Composable
fun BackupScreen(onBack: () -> Unit, onExport: () -> Unit, onImport: () -> Unit, message: String) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Outlined.ArrowBack, contentDescription = "Kembali") }; Text("Cadangan & pemulihan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis) }
        Spacer(Modifier.height(12.dp))
        TermlyCard {
            Text("Data tetap di perangkat", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text("Ekspor membuat file JSON yang berisi mata kuliah, jadwal, deadline, semester, dan nilai. Simpan file tersebut di tempat aman. Impor akan menambahkan data yang ada di file ke database lokal.")
            Spacer(Modifier.height(14.dp))
            Button(onClick = onExport, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Icon(Icons.Outlined.FileDownload, null); Spacer(Modifier.width(8.dp)); Text("Ekspor cadangan JSON") }
            OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Icon(Icons.Outlined.FileUpload, null); Spacer(Modifier.width(8.dp)); Text("Pilih file cadangan JSON") }
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable
fun OnboardingScreen(onImport: (String) -> Unit, onManual: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(76.dp).background(Teal, RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Outlined.School, contentDescription = null, tint = Color.White, modifier = Modifier.size(38.dp)) }
        Spacer(Modifier.height(22.dp))
        Text("Kuliah lebih tertata.", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(8.dp))
        Text("Atur jadwal, ingat deadline, dan pantau IPS/IPK dalam satu tempat. Data tersimpan secara lokal di perangkat.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(28.dp))
        Button(onClick = { onImport("krs") }, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Icon(Icons.Outlined.FileOpen, null); Spacer(Modifier.width(8.dp)); Text("Impor KRS sekarang") }
        OutlinedButton(onClick = onManual, modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("Mulai secara manual") }
    }
}

@Composable
private fun AnimatedGpa(value: Double?, style: androidx.compose.ui.text.TextStyle, color: Color) {
    val target = value?.toFloat() ?: 0f
    val animated by animateFloatAsState(targetValue = target, animationSpec = tween(durationMillis = 650), label = "gpaCount")
    Text(value?.let { String.format(Locale.US, "%.2f", animated) } ?: "—", style = style, fontWeight = FontWeight.ExtraBold, color = color, maxLines = 1, overflow = TextOverflow.Clip)
}
