package com.termly.app.ui.theme

import androidx.compose.ui.graphics.Color

val Teal = Color(0xFF0F766E)
val TealLight = Color(0xFF14B8A6)
val Amber = Color(0xFFF59E0B)
val BackgroundLight = Color(0xFFF6F8F8)
val SurfaceLight = Color(0xFFFFFFFF)
val BackgroundDark = Color(0xFF172329)
val SurfaceDark = Color(0xFF202F36)
val TextDark = Color(0xFF15272A)
val Purple = Color(0xFF7C3AED)
val Success = Color(0xFF15803D)
val Danger = Color(0xFFDC2626)
val Muted = Color(0xFF64748B)
