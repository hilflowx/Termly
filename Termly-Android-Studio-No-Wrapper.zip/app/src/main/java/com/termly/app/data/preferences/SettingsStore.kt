package com.termly.app.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.termlyDataStore by preferencesDataStore(name = "termly_settings")

data class ProfileSettings(
    val name: String = "Mahasiswa",
    val nim: String = "",
    val programStudi: String = "",
    val fakultas: String = "",
    val universitas: String = "",
    val themeMode: String = "system",
    val dynamicColor: Boolean = false,
    val onboardingComplete: Boolean = false,
    val repeatedGradeRule: String = "highest",
    val reminderDayBefore: Boolean = true,
    val reminderHoursBefore: Int = 3,
    val bobotA: Double = 4.0,
    val bobotB: Double = 3.0,
    val bobotC: Double = 2.0,
    val bobotD: Double = 1.0,
    val bobotE: Double = 0.0
)

class SettingsStore(private val context: Context) {
    private object Keys {
        val name = stringPreferencesKey("profile_name")
        val nim = stringPreferencesKey("profile_nim")
        val prodi = stringPreferencesKey("profile_prodi")
        val fakultas = stringPreferencesKey("profile_fakultas")
        val universitas = stringPreferencesKey("profile_universitas")
        val theme = stringPreferencesKey("theme_mode")
        val dynamic = booleanPreferencesKey("dynamic_color")
        val onboarding = booleanPreferencesKey("onboarding_complete")
        val repeatRule = stringPreferencesKey("repeat_grade_rule")
        val remindDay = booleanPreferencesKey("reminder_day_before")
        val remindHours = intPreferencesKey("reminder_hours_before")
        val a = doublePreferencesKey("grade_a")
        val b = doublePreferencesKey("grade_b")
        val c = doublePreferencesKey("grade_c")
        val d = doublePreferencesKey("grade_d")
        val e = doublePreferencesKey("grade_e")
    }

    val settings: Flow<ProfileSettings> = context.termlyDataStore.data.map { p ->
        ProfileSettings(
            name = p[Keys.name] ?: "Mahasiswa", nim = p[Keys.nim] ?: "",
            programStudi = p[Keys.prodi] ?: "", fakultas = p[Keys.fakultas] ?: "",
            universitas = p[Keys.universitas] ?: "", themeMode = p[Keys.theme] ?: "system",
            dynamicColor = p[Keys.dynamic] ?: false, onboardingComplete = p[Keys.onboarding] ?: false,
            repeatedGradeRule = p[Keys.repeatRule] ?: "highest", reminderDayBefore = p[Keys.remindDay] ?: true,
            reminderHoursBefore = p[Keys.remindHours] ?: 3,
            bobotA = p[Keys.a] ?: 4.0, bobotB = p[Keys.b] ?: 3.0, bobotC = p[Keys.c] ?: 2.0,
            bobotD = p[Keys.d] ?: 1.0, bobotE = p[Keys.e] ?: 0.0
        )
    }

    suspend fun updateProfile(name: String, nim: String, prodi: String, fakultas: String, universitas: String) {
        context.termlyDataStore.edit { p ->
            p[Keys.name] = name.trim().ifBlank { "Mahasiswa" }
            p[Keys.nim] = nim.trim(); p[Keys.prodi] = prodi.trim(); p[Keys.fakultas] = fakultas.trim(); p[Keys.universitas] = universitas.trim()
        }
    }
    suspend fun setOnboardingComplete(value: Boolean) { context.termlyDataStore.edit { it[Keys.onboarding] = value } }
    suspend fun setTheme(mode: String) { context.termlyDataStore.edit { it[Keys.theme] = mode } }
    suspend fun setDynamicColor(value: Boolean) { context.termlyDataStore.edit { it[Keys.dynamic] = value } }
    suspend fun setRepeatRule(value: String) { context.termlyDataStore.edit { it[Keys.repeatRule] = value } }
    suspend fun setReminders(dayBefore: Boolean, hoursBefore: Int) { context.termlyDataStore.edit { it[Keys.remindDay] = dayBefore; it[Keys.remindHours] = hoursBefore.coerceIn(1, 48) } }
    suspend fun setGradeWeights(a: Double, b: Double, c: Double, d: Double, e: Double) {
        context.termlyDataStore.edit { p ->
            p[Keys.a] = a.coerceIn(0.0, 4.0); p[Keys.b] = b.coerceIn(0.0, 4.0); p[Keys.c] = c.coerceIn(0.0, 4.0)
            p[Keys.d] = d.coerceIn(0.0, 4.0); p[Keys.e] = e.coerceIn(0.0, 4.0)
        }
    }
    suspend fun restore(settings: ProfileSettings) {
        context.termlyDataStore.edit { p ->
            p[Keys.name] = settings.name
            p[Keys.nim] = settings.nim
            p[Keys.prodi] = settings.programStudi
            p[Keys.fakultas] = settings.fakultas
            p[Keys.universitas] = settings.universitas
            p[Keys.theme] = settings.themeMode
            p[Keys.dynamic] = settings.dynamicColor
            p[Keys.onboarding] = settings.onboardingComplete
            p[Keys.repeatRule] = settings.repeatedGradeRule
            p[Keys.remindDay] = settings.reminderDayBefore
            p[Keys.remindHours] = settings.reminderHoursBefore.coerceIn(1, 48)
            p[Keys.a] = settings.bobotA.coerceIn(0.0, 4.0)
            p[Keys.b] = settings.bobotB.coerceIn(0.0, 4.0)
            p[Keys.c] = settings.bobotC.coerceIn(0.0, 4.0)
            p[Keys.d] = settings.bobotD.coerceIn(0.0, 4.0)
            p[Keys.e] = settings.bobotE.coerceIn(0.0, 4.0)
        }
    }
}
