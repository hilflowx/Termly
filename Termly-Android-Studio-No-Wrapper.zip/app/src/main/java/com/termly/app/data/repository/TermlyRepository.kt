package com.termly.app.data.repository

import com.termly.app.data.local.*
import androidx.room.withTransaction
import org.json.JSONObject
import org.json.JSONArray
import kotlinx.coroutines.flow.Flow

class TermlyRepository(private val db: TermlyDatabase) {
    val subjects: Flow<List<MataKuliahEntity>> = db.mataKuliahDao().observeAll()
    val semesters: Flow<List<SemesterEntity>> = db.semesterDao().observeAll()
    val grades: Flow<List<NilaiEntity>> = db.nilaiDao().observeAll()
    val routines: Flow<List<SesiRutinEntity>> = db.sesiRutinDao().observeAll()
    val exceptions: Flow<List<SesiPengecualianEntity>> = db.sesiPengecualianDao().observeAll()
    val deadlines: Flow<List<DeadlineEntity>> = db.deadlineDao().observeAll()

    suspend fun upsertSubject(name: String, sks: Int, lecturer: String): Long {
        val existing = db.mataKuliahDao().getByName(name.trim())
        return db.mataKuliahDao().insert(MataKuliahEntity(existing?.id ?: 0, name.trim(), sks.coerceIn(1, 6), lecturer.trim()))
    }
    suspend fun findOrCreateSubject(name: String, sks: Int): Long {
        val existing = db.mataKuliahDao().getByName(name.trim())
        return existing?.id ?: upsertSubject(name, sks, "")
    }
    suspend fun addSemester(label: String): Long = db.semesterDao().getByLabel(label.trim())?.id ?: db.semesterDao().insert(SemesterEntity(label = label.trim()))
    suspend fun addGrade(courseId: Long, semesterId: Long, letter: String) {
        db.nilaiDao().deleteForCourseSemester(courseId, semesterId)
        db.nilaiDao().insert(NilaiEntity(mataKuliahId = courseId, semesterId = semesterId, nilaiHuruf = letter.trim().uppercase()))
    }
    suspend fun addRoutine(courseId: Long, day: Int, start: String, end: String, room: String) {
        db.sesiRutinDao().insert(SesiRutinEntity(mataKuliahId = courseId, hari = day.coerceIn(1, 7), jamMulai = start, jamSelesai = end, ruang = room.trim()))
    }
    suspend fun addException(date: String, type: String, courseId: Long, start: String, end: String, room: String, routineId: Long? = null) {
        db.sesiPengecualianDao().insert(SesiPengecualianEntity(tanggal = date, jenis = type, mataKuliahId = courseId, jamMulai = start, jamSelesai = end, ruang = room.trim(), routineSessionId = routineId))
    }
    suspend fun addDeadline(courseId: Long, title: String, timeMillis: Long, reminders: Boolean = true): Long =
        db.deadlineDao().insert(DeadlineEntity(mataKuliahId = courseId, judul = title.trim(), waktu = timeMillis, pengingatAktif = reminders))
    suspend fun markDeadline(id: Long, done: Boolean) = db.deadlineDao().setDone(id, done)
    suspend fun deleteDeadline(id: Long) = db.deadlineDao().deleteById(id)
    suspend fun restoreBackup(json: String) {
        val root = JSONObject(json)
        require(root.optInt("version", -1) == 1) { "Versi cadangan tidak didukung." }
        db.withTransaction {
            val courseIds = mutableMapOf<Long, Long>()
            val semesterIds = mutableMapOf<Long, Long>()
            val routineIds = mutableMapOf<Long, Long>()
            val subjectsArray = root.optJSONArray("subjects") ?: JSONArray()
            for (i in 0 until subjectsArray.length()) {
                val item = subjectsArray.getJSONObject(i)
                val oldId = item.optLong("id", 0)
                val name = item.optString("name").trim()
                if (name.isBlank()) continue
                val existing = db.mataKuliahDao().getByName(name)
                val newId = if (existing != null) db.mataKuliahDao().insert(existing.copy(sks = item.optInt("sks", existing.sks).coerceIn(1, 6), dosen = item.optString("lecturer", existing.dosen)))
                else db.mataKuliahDao().insert(MataKuliahEntity(nama = name, sks = item.optInt("sks", 2).coerceIn(1, 6), dosen = item.optString("lecturer")))
                if (oldId > 0) courseIds[oldId] = newId
            }
            val semesterArray = root.optJSONArray("semesters") ?: JSONArray()
            for (i in 0 until semesterArray.length()) {
                val item = semesterArray.getJSONObject(i)
                val oldId = item.optLong("id", 0)
                val label = item.optString("label").trim()
                if (label.isBlank()) continue
                val newId = db.semesterDao().getByLabel(label)?.id ?: db.semesterDao().insert(SemesterEntity(label = label))
                if (oldId > 0) semesterIds[oldId] = newId
            }
            val gradesArray = root.optJSONArray("grades") ?: JSONArray()
            for (i in 0 until gradesArray.length()) {
                val item = gradesArray.getJSONObject(i)
                val courseId = courseIds[item.optLong("courseId")] ?: continue
                val semesterId = semesterIds[item.optLong("semesterId")] ?: continue
                val letter = item.optString("letter").trim().uppercase()
                if (letter in setOf("A", "B", "C", "D", "E")) {
                    db.nilaiDao().deleteForCourseSemester(courseId, semesterId)
                    db.nilaiDao().insert(NilaiEntity(mataKuliahId = courseId, semesterId = semesterId, nilaiHuruf = letter))
                }
            }
            val routineArray = root.optJSONArray("routines") ?: JSONArray()
            for (i in 0 until routineArray.length()) {
                val item = routineArray.getJSONObject(i)
                val courseId = courseIds[item.optLong("courseId")] ?: continue
                val oldId = item.optLong("id", 0)
                val day = item.optInt("day", 1).coerceIn(1, 7)
                val start = item.optString("start", "08:00")
                val end = item.optString("end", "09:00")
                val room = item.optString("room")
                val matching = db.sesiRutinDao().getAll().firstOrNull { it.mataKuliahId == courseId && it.hari == day && it.jamMulai == start && it.jamSelesai == end && it.ruang == room }
                val newId = matching?.id ?: db.sesiRutinDao().insert(SesiRutinEntity(mataKuliahId = courseId, hari = day, jamMulai = start, jamSelesai = end, ruang = room))
                if (oldId > 0) routineIds[oldId] = newId
            }
            val exceptionArray = root.optJSONArray("exceptions") ?: JSONArray()
            for (i in 0 until exceptionArray.length()) {
                val item = exceptionArray.getJSONObject(i)
                val courseId = courseIds[item.optLong("courseId")] ?: continue
                val type = item.optString("type")
                if (type !in setOf("tambah", "pindah", "batal")) continue
                val date = item.optString("date")
                if (date.isBlank()) continue
                val start = item.optString("start")
                val end = item.optString("end")
                val room = item.optString("room")
                val routineId = routineIds[item.optLong("routineId")]
                val existingException = db.sesiPengecualianDao().getAll().firstOrNull { it.tanggal == date && it.jenis == type && it.mataKuliahId == courseId && it.jamMulai == start && it.jamSelesai == end && it.ruang == room && it.routineSessionId == routineId }
                if (existingException == null) db.sesiPengecualianDao().insert(SesiPengecualianEntity(
                    tanggal = date, jenis = type, mataKuliahId = courseId, jamMulai = start,
                    jamSelesai = end, ruang = room, routineSessionId = routineId
                ))
            }
            val deadlineArray = root.optJSONArray("deadlines") ?: JSONArray()
            for (i in 0 until deadlineArray.length()) {
                val item = deadlineArray.getJSONObject(i)
                val courseId = courseIds[item.optLong("courseId")] ?: continue
                val title = item.optString("title").trim()
                val time = item.optLong("time")
                val existingDeadline = db.deadlineDao().getAll().firstOrNull { it.mataKuliahId == courseId && it.judul == title && it.waktu == time }
                if (title.isNotBlank() && existingDeadline == null) db.deadlineDao().insert(DeadlineEntity(mataKuliahId = courseId, judul = title, waktu = time, status = item.optBoolean("done", false), pengingatAktif = item.optBoolean("reminders", true)))
            }
        }
    }

    suspend fun allSubjects(): List<MataKuliahEntity> = db.mataKuliahDao().getAll()
    suspend fun allRoutines(): List<SesiRutinEntity> = db.sesiRutinDao().getAll()
    suspend fun allExceptionsFor(date: String): List<SesiPengecualianEntity> = db.sesiPengecualianDao().byDate(date)
    suspend fun importSubject(name: String, sks: Int, lecturer: String = ""): Long = upsertSubject(name, sks.coerceAtLeast(1), lecturer)
}
