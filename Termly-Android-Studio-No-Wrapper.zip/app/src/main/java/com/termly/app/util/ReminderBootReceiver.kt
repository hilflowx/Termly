package com.termly.app.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.termly.app.TermlyApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class ReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pendingResult = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val app = appContext as TermlyApplication
                val settings = app.settingsStore.settings.first()
                app.database.deadlineDao().getAll().forEach { deadline ->
                    ReminderScheduler.schedule(appContext, deadline, settings.reminderDayBefore, settings.reminderHoursBefore)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
