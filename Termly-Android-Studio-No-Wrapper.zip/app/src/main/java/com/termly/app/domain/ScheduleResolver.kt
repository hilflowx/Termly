package com.termly.app.domain

import com.termly.app.data.local.SesiPengecualianEntity
import com.termly.app.data.local.SesiRutinEntity
import java.time.LocalDate

enum class SessionKind { ROUTINE, ADDED, MOVED, CANCELLED }
data class ResolvedSession(
    val courseId: Long,
    val start: String,
    val end: String,
    val room: String,
    val kind: SessionKind,
    val sourceRoutineId: Long? = null,
    val sourceExceptionId: Long? = null
)

object ScheduleResolver {
    fun resolve(date: LocalDate, routines: List<SesiRutinEntity>, exceptions: List<SesiPengecualianEntity>): List<ResolvedSession> {
        val daily = exceptions.filter { it.tanggal == date.toString() }
        val replacingIds = daily.filter { it.jenis.lowercase() in setOf("pindah", "batal") }
            .mapNotNull { it.routineSessionId }.toSet()
        val result = routines.filter { it.hari == date.dayOfWeek.value }.map { routine ->
            val replacement = daily.firstOrNull { it.routineSessionId == routine.id && it.jenis.equals("batal", true) }
            val moved = daily.firstOrNull { it.routineSessionId == routine.id && it.jenis.equals("pindah", true) }
            when {
                replacement != null -> ResolvedSession(routine.mataKuliahId, routine.jamMulai, routine.jamSelesai, routine.ruang, SessionKind.CANCELLED, routine.id, replacement.id)
                moved != null -> ResolvedSession(routine.mataKuliahId, routine.jamMulai, routine.jamSelesai, routine.ruang, SessionKind.CANCELLED, routine.id, moved.id)
                routine.id in replacingIds -> null
                else -> ResolvedSession(routine.mataKuliahId, routine.jamMulai, routine.jamSelesai, routine.ruang, SessionKind.ROUTINE, routine.id)
            }
        }.filterNotNull().toMutableList()
        daily.filter { it.jenis.equals("tambah", true) }.forEach { ex ->
            result += ResolvedSession(ex.mataKuliahId, ex.jamMulai, ex.jamSelesai, ex.ruang, SessionKind.ADDED, sourceExceptionId = ex.id)
        }
        daily.filter { it.jenis.equals("pindah", true) }.forEach { ex ->
            result += ResolvedSession(ex.mataKuliahId, ex.jamMulai, ex.jamSelesai, ex.ruang, SessionKind.MOVED, ex.routineSessionId, ex.id)
        }
        return result.sortedBy { it.start }
    }
}
