package com.termly.app.ui.navigation

import android.content.Intent
import android.app.Activity
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.glance.appwidget.updateAll
import android.provider.Settings as AndroidSystemSettings
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.termly.app.ui.TermlyViewModel
import com.termly.app.ui.components.*
import com.termly.app.ui.forms.EntryDialog
import com.termly.app.ui.forms.EntryType
import com.termly.app.ui.importing.ImportScreen
import com.termly.app.ui.screens.*
import com.termly.app.widget.TermlyWidget
import java.time.LocalDate
import kotlinx.coroutines.launch

private data class TabItem(val route: String, val label: String, val inactive: androidx.compose.ui.graphics.vector.ImageVector, val active: androidx.compose.ui.graphics.vector.ImageVector)
private val tabs = listOf(
    TabItem("home", "Beranda", Icons.Outlined.Home, Icons.Filled.Home),
    TabItem("schedule", "Jadwal", Icons.Outlined.CalendarMonth, Icons.Filled.CalendarMonth),
    TabItem("tasks", "Tugas", Icons.Outlined.CheckCircleOutline, Icons.Filled.CheckCircle),
    TabItem("grades", "Nilai", Icons.Outlined.School, Icons.Filled.School),
    TabItem("profile", "Profil", Icons.Outlined.Person, Icons.Filled.Person)
)

@OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
@Composable
fun TermlyApp(viewModel: TermlyViewModel) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route ?: "onboarding"
    val context = LocalContext.current
    val widthClass = (context as? Activity)?.let { calculateWindowSizeClass(it).widthSizeClass } ?: WindowWidthSizeClass.Compact
    val scope = rememberCoroutineScope()
    val subjects by viewModel.subjects.collectAsState()
    val semesters by viewModel.semesters.collectAsState()
    val grades by viewModel.grades.collectAsState()
    val routines by viewModel.routines.collectAsState()
    val exceptions by viewModel.exceptions.collectAsState()
    val deadlines by viewModel.deadlines.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val isPrimary = tabs.any { it.route == route }
    var fabExpanded by remember { mutableStateOf(false) }
    var fabVisible by remember { mutableStateOf(true) }
    var entryType by remember { mutableStateOf<EntryType?>(null) }
    var showProfileEdit by remember { mutableStateOf(false) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var scheduleMode by remember { mutableStateOf("day") }
    var backupMessage by remember { mutableStateOf("") }
    var backupJson by remember { mutableStateOf("") }

    LaunchedEffect(deadlines, settings.reminderDayBefore, settings.reminderHoursBefore) {
        deadlines.forEach { deadline -> com.termly.app.util.ReminderScheduler.cancel(context, deadline); com.termly.app.util.ReminderScheduler.schedule(context, deadline, settings.reminderDayBefore, settings.reminderHoursBefore) }
    }

    val launcherExport = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null && backupJson.isNotBlank()) runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(backupJson.toByteArray()) }; backupMessage = "Cadangan berhasil diekspor." }.onFailure { backupMessage = "Ekspor gagal: ${it.message}" }
    }
    val launcherImport = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching { context.contentResolver.openInputStream(uri)?.use { it.readBytes().decodeToString() } ?: error("File tidak dapat dibuka") }
                .onSuccess { json -> viewModel.restoreBackup(json) { message -> backupMessage = message } }
                .onFailure { backupMessage = "File cadangan tidak bisa dibaca: ${it.message ?: "format tidak valid"}" }
        }
    }

    BackHandler(enabled = fabExpanded) { fabExpanded = false }
    LaunchedEffect(route) { fabExpanded = false; fabVisible = true }
    LaunchedEffect(settings.onboardingComplete, route) {
        if (settings.onboardingComplete && route == "onboarding") {
            nav.navigate("home") { popUpTo("onboarding") { inclusive = true }; launchSingleTop = true }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            if (isPrimary && !fabExpanded) NavigationBar(windowInsets = WindowInsets.navigationBars) {
                tabs.forEach { item ->
                    val selected = route == item.route
                    NavigationBarItem(selected = selected, onClick = { nav.navigate(item.route) { popUpTo(nav.graph.findStartDestination().id) { saveState = true }; launchSingleTop = true; restoreState = true } },
                        icon = { Icon(if (selected) item.active else item.inactive, contentDescription = null) },
                        label = { Text(item.label, maxLines = 1, overflow = TextOverflow.Ellipsis) }, alwaysShowLabel = true)
                }
            }
        },
        floatingActionButton = {
            if (isPrimary && route != "profile" && fabVisible) {
                if (route == "home") {
                    BoxWithConstraints {
                        val menuMaxHeight = (maxHeight - 96.dp).coerceAtLeast(120.dp)
                        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (fabExpanded) {
                                Column(Modifier.heightIn(max = menuMaxHeight).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.End) {
                                    SpeedDialRow("Tambah sesi kuliah", Icons.Outlined.CalendarMonth) { entryType = EntryType.SESSION; fabExpanded = false }
                                    SpeedDialRow("Tambah tugas / deadline", Icons.Outlined.NotificationsActive) { entryType = EntryType.DEADLINE; fabExpanded = false }
                                    SpeedDialRow("Tambah mata kuliah", Icons.Outlined.MenuBook) { entryType = EntryType.SUBJECT; fabExpanded = false }
                                    SpeedDialRow("Tambah nilai", Icons.Outlined.School) { entryType = EntryType.GRADE; fabExpanded = false }
                                    SpeedDialRow("Impor KRS / KHS", Icons.Outlined.FileOpen) { nav.navigate("import/krs"); fabExpanded = false }
                                }
                            }
                            val angle by animateFloatAsState(if (fabExpanded) 45f else 0f, label = "fabRotation")
                            FloatingActionButton(onClick = { fabExpanded = !fabExpanded }, containerColor = Teal, contentColor = Color.White) { Icon(Icons.Default.Add, contentDescription = if (fabExpanded) "Tutup menu tambah" else "Buka menu tambah", modifier = Modifier.rotate(angle)) }
                        }
                    }
                } else {
                    FloatingActionButton(onClick = { entryType = when (route) { "schedule" -> EntryType.SESSION; "tasks" -> EntryType.DEADLINE; else -> EntryType.GRADE } }, containerColor = Teal, contentColor = Color.White) { Icon(Icons.Default.Add, contentDescription = "Tambah") }
                }
            }
        }
    ) { innerPadding ->
        Box(Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.TopCenter) {
            val contentModifier = if (widthClass == WindowWidthSizeClass.Compact) Modifier.fillMaxSize() else Modifier.widthIn(max = 600.dp).fillMaxHeight()
            NavHost(navController = nav, startDestination = if (settings.onboardingComplete) "home" else "onboarding", modifier = contentModifier) {
                composable("onboarding") { OnboardingScreen(onImport = { kind -> viewModel.completeOnboarding(); nav.navigate("import/$kind") }, onManual = { viewModel.completeOnboarding(); nav.navigate("home") { popUpTo("onboarding") { inclusive = true } } }) }
                composable("home") {
                    var clockTick by remember { mutableLongStateOf(System.currentTimeMillis()) }
                    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(30_000); clockTick = System.currentTimeMillis() } }
                    val todaySessions = remember(routines, exceptions, clockTick) { viewModel.resolvedSessions(LocalDate.now()) }
                    val nextUpcoming = remember(routines, exceptions, clockTick) { viewModel.nextUpcomingSession() }
                    val lastSemesterId = semesters.lastOrNull()?.id
                    HomeScreen(settings, subjects, todaySessions, nextUpcoming, deadlines, viewModel.ipk(), lastSemesterId?.let(viewModel::semesterIps),
                        onAdd = { entryType = EntryType.SESSION }, onTasks = { nav.navigate("tasks") }, onSchedule = { nav.navigate("schedule") }, onValues = { nav.navigate("grades") }, onScroll = { fabVisible = it })
                }
                composable("schedule") {
                    val result = remember(selectedDate, routines, exceptions) { viewModel.resolvedSessions(selectedDate) }
                    ScheduleScreen(selectedDate, { selectedDate = it }, routines, exceptions, result, subjects, scheduleMode, { scheduleMode = it }, { entryType = EntryType.SESSION }, { fabVisible = it })
                }
                composable("tasks") { TasksScreen(deadlines, subjects, viewModel::toggleDeadline, viewModel::deleteDeadline, { entryType = EntryType.DEADLINE }, { fabVisible = it }) }
                composable("grades") { GradesScreen(subjects, semesters, grades, viewModel.ipk(), viewModel::semesterIps, viewModel::simulateIpk, { entryType = EntryType.GRADE }, { fabVisible = it }) }
                composable("profile") {
                    ProfileScreen(settings, { showProfileEdit = true }, { nav.navigate("import/krs") }, { nav.navigate("settings") }, { nav.navigate("courses") }, { nav.navigate("backup") }, { fabVisible = it })
                }
                composable("courses") { CoursesScreen(subjects, { entryType = EntryType.SUBJECT }, { nav.popBackStack() }) }
                composable("settings") { SettingsScreen(settings, { nav.popBackStack() }, viewModel::setTheme, viewModel::setDynamicColor, viewModel::setRepeatRule, viewModel::setReminders, viewModel::setGradeWeights, { nav.navigate("backup") }, {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) runCatching {
                        context.startActivity(Intent(AndroidSystemSettings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")))
                    }
                }) }
                composable("import/{kind}") { entry ->
                    val kind = entry.arguments?.getString("kind") ?: "krs"
                    ImportScreen(kind, viewModel, { nav.popBackStack() }, { nextKind -> nav.navigate("import/$nextKind") { launchSingleTop = true } }, { nav.navigate("home") { launchSingleTop = true } })
                }
                composable("backup") {
                    BackupScreen({ nav.popBackStack() }, {
                        backupJson = buildBackupJson(subjects, semesters, grades, routines, exceptions, deadlines, settings)
                        launcherExport.launch("termly-backup-${System.currentTimeMillis()}.json")
                    }, { launcherImport.launch(arrayOf("application/json", "text/*")) }, backupMessage)
                }
            }
            if (fabExpanded && route == "home") Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.25f)).clickable { fabExpanded = false })
        }
    }

    if (entryType != null) EntryDialog(
        type = entryType!!, subjects = subjects, routines = routines, onDismiss = { entryType = null },
        onSaveSubject = { name, sks, lecturer -> viewModel.addSubject(name, sks, lecturer) },
        onSaveSession = { course, day, start, end, room, kind, date, routineId ->
            if (kind == "rutin") viewModel.addRoutine(course, day, start, end, room)
            else viewModel.addException(date, kind, course, if (kind == "batal") "" else start, if (kind == "batal") "" else end, room, routineId)
        },
        onSaveDeadline = viewModel::addDeadline,
        onSaveGrade = viewModel::addGrade
    )
    if (showProfileEdit) ProfileEditDialog(settings, { showProfileEdit = false }, viewModel::saveProfile)
}

@Composable
private fun SpeedDialRow(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.End) {
        Surface(color = MaterialTheme.colorScheme.surface, contentColor = MaterialTheme.colorScheme.onSurface, shape = MaterialTheme.shapes.medium, shadowElevation = 3.dp) { Text(label, modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp), fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        Spacer(Modifier.width(10.dp))
        SmallFloatingActionButton(onClick = onClick, containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer) { Icon(icon, contentDescription = label) }
    }
}

private fun buildBackupJson(
    subjects: List<com.termly.app.data.local.MataKuliahEntity>,
    semesters: List<com.termly.app.data.local.SemesterEntity>,
    grades: List<com.termly.app.data.local.NilaiEntity>,
    routines: List<com.termly.app.data.local.SesiRutinEntity>,
    exceptions: List<com.termly.app.data.local.SesiPengecualianEntity>,
    deadlines: List<com.termly.app.data.local.DeadlineEntity>, settings: com.termly.app.data.preferences.ProfileSettings
): String {
    fun quote(value: String): String = "\"" + value
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\b", "\\b").replace("\u000C", "\\f").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t") + "\""

    return buildString {
        append("{\"version\":1,\"profile\":{\"name\":${quote(settings.name)},\"nim\":${quote(settings.nim)},\"programStudi\":${quote(settings.programStudi)},\"fakultas\":${quote(settings.fakultas)},\"universitas\":${quote(settings.universitas)},\"themeMode\":${quote(settings.themeMode)},\"dynamicColor\":${settings.dynamicColor},\"onboardingComplete\":${settings.onboardingComplete},\"repeatedGradeRule\":${quote(settings.repeatedGradeRule)},\"reminderDayBefore\":${settings.reminderDayBefore},\"reminderHoursBefore\":${settings.reminderHoursBefore},\"bobotA\":${settings.bobotA},\"bobotB\":${settings.bobotB},\"bobotC\":${settings.bobotC},\"bobotD\":${settings.bobotD},\"bobotE\":${settings.bobotE}},\"subjects\":[")
        append(subjects.joinToString(",") { "{\"id\":${it.id},\"name\":${quote(it.nama)},\"sks\":${it.sks},\"lecturer\":${quote(it.dosen)}}" })
        append("],\"semesters\":[")
        append(semesters.joinToString(",") { "{\"id\":${it.id},\"label\":${quote(it.label)}}" })
        append("],\"grades\":[")
        append(grades.joinToString(",") { "{\"courseId\":${it.mataKuliahId},\"semesterId\":${it.semesterId},\"letter\":${quote(it.nilaiHuruf)}}" })
        append("],\"routines\":[")
        append(routines.joinToString(",") { "{\"id\":${it.id},\"courseId\":${it.mataKuliahId},\"day\":${it.hari},\"start\":${quote(it.jamMulai)},\"end\":${quote(it.jamSelesai)},\"room\":${quote(it.ruang)}}" })
        append("],\"exceptions\":[")
        append(exceptions.joinToString(",") { "{\"courseId\":${it.mataKuliahId},\"date\":${quote(it.tanggal)},\"type\":${quote(it.jenis)},\"start\":${quote(it.jamMulai)},\"end\":${quote(it.jamSelesai)},\"room\":${quote(it.ruang)},\"routineId\":${it.routineSessionId ?: 0}}" })
        append("],\"deadlines\":[")
        append(deadlines.joinToString(",") { "{\"courseId\":${it.mataKuliahId},\"title\":${quote(it.judul)},\"time\":${it.waktu},\"done\":${it.status},\"reminders\":${it.pengingatAktif}}" })
        append("]}")
    }
}
