package com.termly.app.widget

import android.content.Context
import android.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Column
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.termly.app.data.local.TermlyDatabase
import com.termly.app.domain.ScheduleResolver
import com.termly.app.domain.SessionKind
import kotlinx.coroutines.flow.first
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class TermlyWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Responsive(setOf(DpSize(180.dp, 90.dp), DpSize(250.dp, 120.dp)))

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val db = TermlyDatabase.getInstance(context)
        val deadlines = db.deadlineDao().observeAll().first().filter { !it.status && it.waktu > System.currentTimeMillis() }.sortedBy { it.waktu }
        val subjects = db.mataKuliahDao().observeAll().first().associateBy { it.id }
        val routines = db.sesiRutinDao().observeAll().first()
        val exceptions = db.sesiPengecualianDao().observeAll().first()
        val nowDate = LocalDate.now()
        val nowTime = LocalTime.now()
        val nextClass = (0..6).asSequence().mapNotNull { offset ->
            val date = nowDate.plusDays(offset.toLong())
            ScheduleResolver.resolve(date, routines, exceptions)
                .filter { it.kind != SessionKind.CANCELLED }
                .filter { offset > 0 || runCatching { LocalTime.parse(it.start).isAfter(nowTime) }.getOrDefault(false) }
                .minByOrNull { it.start }?.let { session -> date to session }
        }.firstOrNull()
        val nearest = deadlines.firstOrNull()
        provideContent {
            Column(GlanceModifier.fillMaxSize().background(ColorProvider(Color.rgb(242, 249, 248))).padding(12.dp)) {
                Text("Termly", style = TextStyle(color = ColorProvider(Color.rgb(15, 118, 110))))
                if (nextClass != null) {
                    val (date, session) = nextClass
                    Text("Kuliah berikutnya: ${subjects[session.courseId]?.nama ?: "Mata kuliah"}", maxLines = 2)
                    Text("${date.format(DateTimeFormatter.ofPattern("EEE, dd MMM"))} · ${session.start} · ${session.room.ifBlank { "Ruang belum diisi" }}", maxLines = 2)
                } else Text("Belum ada jadwal kuliah", maxLines = 1)
                if (nearest != null) {
                    val formatted = Instant.ofEpochMilli(nearest.waktu).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("dd MMM HH:mm"))
                    Text("Deadline: ${nearest.judul} · $formatted", maxLines = 2)
                } else Text("Tidak ada deadline dekat", maxLines = 1)
            }
        }
    }
}

class TermlyWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = TermlyWidget()
}
