package com.termly.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.termly.app.ui.TermlyViewModel
import com.termly.app.ui.navigation.TermlyApp
import com.termly.app.ui.theme.TermlyTheme

class MainActivity : ComponentActivity() {
    private val requestNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            val app = application as TermlyApplication
            val vm: TermlyViewModel = viewModel(factory = TermlyViewModel.factory(app))
            val settings by vm.settings.collectAsState()
            TermlyTheme(themeMode = settings.themeMode, dynamicColor = settings.dynamicColor) {
                TermlyApp(viewModel = vm)
            }
        }
    }
}
