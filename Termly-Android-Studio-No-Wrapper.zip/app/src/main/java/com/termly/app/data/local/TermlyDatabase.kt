package com.termly.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [MataKuliahEntity::class, SemesterEntity::class, NilaiEntity::class, SesiRutinEntity::class, SesiPengecualianEntity::class, DeadlineEntity::class],
    version = 1,
    exportSchema = true
)
abstract class TermlyDatabase : RoomDatabase() {
    abstract fun mataKuliahDao(): MataKuliahDao
    abstract fun semesterDao(): SemesterDao
    abstract fun nilaiDao(): NilaiDao
    abstract fun sesiRutinDao(): SesiRutinDao
    abstract fun sesiPengecualianDao(): SesiPengecualianDao
    abstract fun deadlineDao(): DeadlineDao

    companion object {
        @Volatile private var INSTANCE: TermlyDatabase? = null
        fun getInstance(context: Context): TermlyDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, TermlyDatabase::class.java, "termly.db").build().also { INSTANCE = it }
        }
    }
}
