package com.termly.app.ui.importing

import android.content.Context
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.Locale

data class ImportPreviewRow(
    val name: String,
    val sks: Int = 2,
    val grade: String = "",
    val day: Int = 0,
    val start: String = "",
    val end: String = "",
    val room: String = "",
    val confidence: Float = 1f
)

data class ImportResult(val rawText: String, val rows: List<ImportPreviewRow>, val sourceLabel: String)

class DocumentImportParser(private val context: Context) {
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    suspend fun parse(uri: Uri, kind: String): ImportResult = withContext(Dispatchers.IO) {
        val mime = context.contentResolver.getType(uri).orEmpty()
        val source = if (mime == "application/pdf" || uri.toString().lowercase().endsWith(".pdf")) "PDF" else "Foto"
        val text = if (source == "PDF") readPdfTextOrOcr(uri) else readImageText(uri)
        ImportResult(text, parseRows(text, kind), source)
    }

    private suspend fun readImageText(uri: Uri): String {
        val image = InputImage.fromFilePath(context, uri)
        return recognizer.process(image).await().text
    }

    private suspend fun readPdfTextOrOcr(uri: Uri): String {
        val text = runCatching {
            context.contentResolver.openInputStream(uri)?.use { input -> PDDocument.load(input).use { PDFTextStripper().getText(it) } }.orEmpty()
        }.getOrDefault("")
        if (text.isNotBlank()) return text
        val descriptor = context.contentResolver.openFileDescriptor(uri, "r") ?: return ""
        return descriptor.use { pfd ->
            val renderer = PdfRenderer(pfd)
            renderer.use { pdf ->
                buildString {
                    for (index in 0 until pdf.pageCount) {
                        val page = pdf.openPage(index)
                        val scale = (1200f / page.width).coerceAtMost(3f)
                        val bitmap = Bitmap.createBitmap((page.width * scale).toInt().coerceAtLeast(1), (page.height * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        page.close()
                        appendLine(recognizer.process(InputImage.fromBitmap(bitmap, 0)).await().text)
                        bitmap.recycle()
                    }
                }
            }
        }
    }

    private fun parseRows(text: String, kind: String): List<ImportPreviewRow> {
        val gradeRegex = Regex("(?<![A-Z])(?:A|B|C|D|E)(?![A-Z])", RegexOption.IGNORE_CASE)
        val sksRegex = Regex("""(?i)(\d{1,2})\s*(?:SKS)?""")
        val timeRegex = Regex("""(\d{1,2}:\d{2})\s*[-– sampai]+\s*(\d{1,2}:\d{2})""", RegexOption.IGNORE_CASE)
        val dayLookup = mapOf("senin" to 1, "selasa" to 2, "rabu" to 3, "kamis" to 4, "jumat" to 5, "jum'at" to 5, "sabtu" to 6, "minggu" to 7,
            "monday" to 1, "tuesday" to 2, "wednesday" to 3, "thursday" to 4, "friday" to 5, "saturday" to 6, "sunday" to 7)
        val output = mutableListOf<ImportPreviewRow>()
        text.lines().map(String::trim).filter { it.length >= 4 }.forEach { line ->
            if (line.contains("mata kuliah", true) || line.contains("semester", true) && line.length < 35 || line.contains("sks", true) && line.length < 20) return@forEach
            val grade = gradeRegex.findAll(line).lastOrNull()?.value?.uppercase().orEmpty()
            val time = timeRegex.find(line)
            val day = dayLookup.entries.firstOrNull { line.lowercase(Locale.ROOT).contains(it.key) }?.value ?: 0
            val sksCandidates = sksRegex.findAll(line).mapNotNull { it.groupValues.getOrNull(1)?.toIntOrNull() }.filter { it in 1..6 }.toList()
            val sks = sksCandidates.lastOrNull() ?: 2
            var name = line
            if (time != null) name = name.replace(time.value, " ")
            if (day > 0) dayLookup.keys.forEach { name = name.replace(Regex(it, RegexOption.IGNORE_CASE), " ") }
            if (grade.isNotBlank()) name = name.replace(Regex("""\b${Regex.escape(grade)}\b""", RegexOption.IGNORE_CASE), " ")
            val lastNum = Regex("""\s+\d{1,2}(?:\s*SKS)?\s*$""", RegexOption.IGNORE_CASE)
            name = name.replace(lastNum, "").replace(Regex("""\s{2,}"""), " ").trim(' ', '-', '|', ':', '.', ',')
            if (name.length < 4 || name.split(' ').size > 16) return@forEach
            val looksLikeHeader = name.contains("universitas", true) || name.contains("program studi", true) || name.contains("kartu hasil", true) || name.contains("kartu rencana", true)
            if (looksLikeHeader) return@forEach
            val conf = when { grade.isBlank() && kind == "khs" -> 0.48f; sksCandidates.isEmpty() -> 0.58f; name.split(' ').size == 1 -> 0.55f; else -> 0.86f }
            output += ImportPreviewRow(name, sks, grade, day, time?.groupValues?.getOrNull(1)?.padStart(5, '0').orEmpty(), time?.groupValues?.getOrNull(2)?.padStart(5, '0').orEmpty(), "", conf)
        }
        return output.distinctBy { it.name.lowercase(Locale.ROOT) }.take(100)
    }
}
