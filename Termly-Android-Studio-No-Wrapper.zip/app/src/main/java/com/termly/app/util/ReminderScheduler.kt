package com.termly.app.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.termly.app.data.local.DeadlineEntity

object ReminderScheduler {
    const val ACTION_REMIND = "com.termly.app.ACTION_DEADLINE_REMINDER"
    const val EXTRA_TITLE = "extra_title"
    const val EXTRA_DEADLINE_ID = "extra_deadline_id"

    fun cancel(context: Context, deadline: DeadlineEntity) {
        // Cancel every supported hour offset so changing reminder settings cannot leave stale alarms.
        val offsets = ((1L..48L).map { it * 60L * 60L * 1000L } + 24L * 60L * 60L * 1000L).distinct()
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        offsets.forEach { offset ->
            val requestCode = (deadline.id * 31L + offset / 60000L).toInt()
            val intent = Intent(context, ReminderReceiver::class.java).apply { action = ACTION_REMIND }
            val pending = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
            if (pending != null) { manager.cancel(pending); pending.cancel() }
        }
    }

    fun schedule(context: Context, deadline: DeadlineEntity, dayBefore: Boolean, hoursBefore: Int) {
        if (!deadline.pengingatAktif || deadline.status) return
        val offsets = buildList {
            if (dayBefore) add(24 * 60L * 60L * 1000L)
            add(hoursBefore.coerceIn(1, 48) * 60L * 60L * 1000L)
        }.distinct()
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        offsets.forEach { offset ->
            val trigger = deadline.waktu - offset
            if (trigger <= System.currentTimeMillis()) return@forEach
            val requestCode = (deadline.id * 31L + offset / 60000L).toInt()
            val intent = Intent(context, ReminderReceiver::class.java).apply {
                action = ACTION_REMIND
                putExtra(EXTRA_TITLE, deadline.judul)
                putExtra(EXTRA_DEADLINE_ID, deadline.id)
            }
            val pending = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && manager.canScheduleExactAlarms()) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
            } else {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending)
            }
        }
    }
}
