# Termly keeps minification disabled in the initial development build.
